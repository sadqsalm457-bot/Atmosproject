#version 460 thick
precision highp float;
#include <flutter/runtime_effect.glsl>

uniform vec2 uSize;
uniform float uTime;
uniform vec2 uScroll;
uniform float uCover;
uniform float uDark;
uniform float uMode;
uniform vec2 uSun;
uniform float uSunStr;
uniform float uWarm;
uniform float uFlash;
uniform float uQuality;
uniform vec3 uLit;
uniform vec3 uShade;
uniform vec3 uLight;
uniform vec3 uHaze;

out vec4 fragColor;

float hash21(vec2 p) {
  vec3 p3 = fract(vec3(p.x, p.y, p.x) * 0.1031);
  p3 = p3 + dot(p3, vec3(p3.y + 33.33, p3.z + 33.33, p3.x + 33.33));
  return fract((p3.x + p3.y) * p3.z);
}

float vnoise(vec2 p) {
  vec2 i = floor(p);
  vec2 f = fract(p);
  vec2 u = f * f * (vec2(3.0) - 2.0 * f);
  float a = hash21(i);
  float b = hash21(i + vec2(1.0, 0.0));
  float c = hash21(i + vec2(0.0, 1.0));
  float d = hash21(i + vec2(1.0, 1.0));
  return mix(mix(a, b, u.x), mix(c, d, u.x), u.y);
}

float fbm(vec2 p, int oct) {
  float v = 0.0;
  float a = 0.5;
  float norm = 0.0;
  for (int i = 0; i < 6; i++) {
    if (i >= oct) {
      break;
    }
    v = v + a * vnoise(p);
    norm = norm + a;
    p = vec2(0.8 * p.x - 0.6 * p.y, 0.6 * p.x + 0.8 * p.y) * 2.03 + vec2(5.2, 1.3);
    a = a * 0.5;
  }
  return v / norm;
}

// One cloud sheet. Returns (density, lightTerm, thick, rim).
vec4 cloudLayer(vec2 uv, vec2 scale, vec2 drift, float thr, float soft,
                float warpAmt, int oct, vec2 ldir, float seed) {
  vec2 p = uv * scale + drift + vec2(seed * 17.0, seed * 9.0);
  float w1 = fbm(p * 0.55 + vec2(1.7, 9.2), 2);
  float w2 = fbm(p * 0.55 + vec2(8.3, 2.8), 2);
  p = p + (vec2(w1, w2) - vec2(0.5)) * warpAmt;
  float n = fbm(p, oct);
  float d = smoothstep(thr, thr + soft, n);
  float nl = fbm(p + ldir * 0.16, oct);
  float dl = smoothstep(thr, thr + soft, nl);
  float lightTerm = clamp(0.45 + (d - dl) * 2.6, 0.0, 1.0);
  float thick = smoothstep(thr + soft * 0.4, thr + soft * 1.6, n);
  float rim = clamp((d - dl) * 3.0, 0.0, 1.0) * (1.0 - thick * 0.6);
  return vec4(d, lightTerm, thick, rim);
}

void main() {
  vec2 fc = FlutterFragCoord().xy;
  vec2 uv = fc / uSize;
  float aspect = uSize.x / uSize.y;
  vec2 q = vec2(uv.x * aspect, uv.y);
  int oct = 3 + int(uQuality);

  vec2 ldir = vec2((uSun.x - uv.x) * aspect, uSun.y - uv.y);
  float ll = length(ldir);
  if (ll < 0.001) {
    ldir = vec2(0.0, -1.0);
  } else {
    ldir = ldir / ll;
  }

  float t = uTime;

  if (uMode > 0.5) {
    // ground fog / mist: soft, low contrast, no rim
    vec2 p = q * vec2(3.2, 2.4) + uScroll * 1.2 + vec2(sin(t * 0.05), cos(t * 0.04)) * 0.3;
    float n = fbm(p, 3);
    float d = (0.35 + 0.65 * smoothstep(0.2, 0.8, n)) * uCover;
    vec3 col = mix(uHaze, uLit, 0.4 + 0.3 * smoothstep(0.3, 0.9, n));
    col = col + uLight * uSunStr * 0.08;
    col = mix(col, vec3(0.9, 0.93, 1.0), uFlash * 0.5);
    float a = clamp(d * 0.75, 0.0, 1.0);
    fragColor = vec4(col * a, a);
    return;
  }

  float cover = clamp(uCover, 0.0, 1.0);
  vec3 outc = vec3(0.0);
  float outa = 0.0;

  // thresholds: more cover -> lower threshold -> denser
  float base = mix(0.74, 0.22, cover);

  for (int L = 0; L < 3; L++) {
    if (L == 2 && uQuality < 0.5) {
      break;
    }
    float fl = float(L);
    vec2 scale;
    float thr;
    float soft;
    float warp;
    float speed;
    float opacity;
    float mask;
    if (L == 0) {
      scale = vec2(2.0, 5.0);
      thr = base + 0.02;
      soft = 0.38;
      warp = 0.8;
      speed = 0.6;
      opacity = 0.85;
      mask = smoothstep(0.80, 0.30, uv.y);
    } else if (L == 1) {
      scale = vec2(2.6, 3.6);
      thr = base + 0.05;
      soft = 0.34;
      warp = 0.9;
      speed = 1.0;
      opacity = 0.90;
      mask = smoothstep(0.88, 0.40, uv.y);
    } else {
      scale = vec2(1.5, 2.0);
      thr = base + 0.08;
      soft = 0.30;
      warp = 0.7;
      speed = 1.6;
      opacity = 0.95;
      mask = smoothstep(0.95, 0.55, uv.y);
    }
    vec2 drift = vec2(uScroll.x * speed, uScroll.y * speed)
               + vec2(sin(t * 0.07 + fl), cos(t * 0.06 + fl * 2.0)) * 0.12;
    vec4 c = cloudLayer(q, scale, drift, thr, soft, warp, oct, ldir, fl + 1.0);
    float a = c.x * opacity * mask;
    if (a < 0.003) {
      continue;
    }

    // light model
    float depthShade = 1.0 - fl * 0.12;
    vec3 litC = mix(uLit, uLight, uWarm * 0.75 * uSunStr);
    vec3 shadeC = uShade * depthShade;
    float k = clamp(c.y * (1.0 - c.z * 0.75 * (1.0 - uSunStr * 0.35)), 0.0, 1.0);
    vec3 col = mix(shadeC, litC, k);
    col = col + uLight * c.w * (0.35 + 0.65 * uWarm) * uSunStr * 0.8;
    // dark storm bodies
    col = mix(col, shadeC * 0.65, uDark * 0.55 * (0.4 + 0.6 * c.z));
    // lightning illumination from inside
    col = mix(col, vec3(0.80, 0.85, 1.0), uFlash * (0.35 + 0.5 * c.z));

    // composite (premultiplied, back to front)
    outc = col * a + outc * (1.0 - a);
    outa = a + outa * (1.0 - a);
  }

  fragColor = vec4(outc, outa);
}
