import 'dart:convert';

import 'package:http/http.dart' as http;
import 'package:intl/intl.dart' show DateFormat;

import '../l10n/strings.dart';
import '../models/app_settings.dart';
import '../models/insight.dart';
import '../models/weather_models.dart';

class AiService {
  static Future<Insight> generate(
    WeatherBundle b,
    AppSettings s,
    String apiKey,
  ) async {
    final c = b.current;
    final today = b.today;
    final tf = DateFormat('HH:mm');
    final unit = s.tempLabel;

    final data = {
      'location': b.place.name,
      'units': {'temperature': unit, 'wind': s.windLabel},
      'now': {
        'condition': Strings.t('en', conditionKey(c.code, c.isDay)),
        'temperature': s.temp(c.temp).round(),
        'feels_like': s.temp(c.feelsLike).round(),
        'humidity_percent': c.humidity,
        'wind': s.wind(c.windKmh).round(),
        'cloud_cover_percent': c.cloud,
        'uv_index': c.uv.round(),
        'is_day': c.isDay,
      },
      'today': {'min': s.temp(today.min).round(), 'max': s.temp(today.max).round()},
      'air_quality_us_aqi': b.air?.aqi,
      'next_hours': [
        for (final h in b.nextHours(14))
          {
            'time': tf.format(h.time),
            'temperature': s.temp(h.temp).round(),
            'rain_chance_percent': h.precipProb.round(),
            'wind': s.wind(h.windKmh).round(),
          },
      ],
    };

    final langName = s.lang == 'ar' ? 'Arabic' : 'English';
    final system =
        'You are a concise, friendly weather assistant. Reply with ONE strict JSON object only. '
        'No markdown, no code fences, no extra text. Keys: "summary" (exactly two short sentences), '
        '"wear" (one short sentence on what to wear), "best_time" (a short time window to go outside, with a brief reason). '
        'Write all values in $langName.';

    final res = await http
        .post(
          Uri.parse('https://api.anthropic.com/v1/messages'),
          headers: {
            'content-type': 'application/json',
            'x-api-key': apiKey,
            'anthropic-version': '2023-06-01',
          },
          body: jsonEncode({
            'model': 'claude-sonnet-4-6',
            'max_tokens': 600,
            'system': system,
            'messages': [
              {'role': 'user', 'content': jsonEncode(data)},
            ],
          }),
        )
        .timeout(const Duration(seconds: 25));

    if (res.statusCode != 200) {
      throw Exception('AI HTTP ${res.statusCode}');
    }
    final j = jsonDecode(utf8.decode(res.bodyBytes)) as Map<String, dynamic>;
    final text = (j['content'] as List)
        .map((e) => (e is Map && e['text'] != null) ? e['text'].toString() : '')
        .join();
    final start = text.indexOf('{');
    final end = text.lastIndexOf('}');
    if (start < 0 || end <= start) throw Exception('AI returned no JSON');
    final m = jsonDecode(text.substring(start, end + 1)) as Map<String, dynamic>;
    final summary = (m['summary'] ?? '').toString().trim();
    final wear = (m['wear'] ?? '').toString().trim();
    final best = (m['best_time'] ?? '').toString().trim();
    if (summary.isEmpty || wear.isEmpty || best.isEmpty) {
      throw Exception('AI JSON incomplete');
    }
    return Insight(summary: summary, wear: wear, bestTime: best, fromAi: true);
  }
}
