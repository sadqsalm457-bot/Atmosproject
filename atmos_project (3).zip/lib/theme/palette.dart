import 'package:flutter/material.dart';

import '../util/math_utils.dart';

class SkyPalette {
  const SkyPalette(
    this.top,
    this.mid,
    this.bottom,
    this.cloudLight,
    this.cloudDark, [
    this.light = const Color(0xFFFFF6E0),
  ]);

  final Color top;
  final Color mid;
  final Color bottom;
  final Color cloudLight;
  final Color cloudDark;

  /// Colour of the sun (or moon) light at this moment.
  final Color light;

  static SkyPalette lerp(SkyPalette a, SkyPalette b, double t) => SkyPalette(
        Color.lerp(a.top, b.top, t)!,
        Color.lerp(a.mid, b.mid, t)!,
        Color.lerp(a.bottom, b.bottom, t)!,
        Color.lerp(a.cloudLight, b.cloudLight, t)!,
        Color.lerp(a.cloudDark, b.cloudDark, t)!,
        Color.lerp(a.light, b.light, t)!,
      );

  static const clearDay = SkyPalette(Color(0xFF1F5FC7), Color(0xFF4A90E2), Color(0xFF8CC5F5), Color(0xFFFFFFFF), Color(0xFFB8CBE6));
  static const clearNight = SkyPalette(Color(0xFF070B24), Color(0xFF141A4A), Color(0xFF2A2F78), Color(0xFF5A63A0), Color(0xFF1D2250));
  static const overcastDay = SkyPalette(Color(0xFF5C6B82), Color(0xFF8593A8), Color(0xFFB4BFCD), Color(0xFFD5DCE8), Color(0xFF7D8BA3));
  static const overcastNight = SkyPalette(Color(0xFF141A2B), Color(0xFF222B42), Color(0xFF39435C), Color(0xFF4A5572), Color(0xFF171E33));
  static const rainDay = SkyPalette(Color(0xFF2E3B55), Color(0xFF47566F), Color(0xFF6C7B93), Color(0xFF8E9CB5), Color(0xFF3B4863));
  static const rainNight = SkyPalette(Color(0xFF10162A), Color(0xFF1B2440), Color(0xFF2C3658), Color(0xFF3A4566), Color(0xFF0F1426));
  static const snowDay = SkyPalette(Color(0xFF5F7399), Color(0xFF8497B8), Color(0xFFB5C3DA), Color(0xFFEAF0FA), Color(0xFF9AAAC6));
  static const snowNight = SkyPalette(Color(0xFF1B2540), Color(0xFF2C3A5C), Color(0xFF4A5C85), Color(0xFF6C7DA6), Color(0xFF2A3658));
  static const fogDay = SkyPalette(Color(0xFF6E7A8C), Color(0xFF8E99A9), Color(0xFFB0B9C6), Color(0xFFE3E7EE), Color(0xFFA4AEBC));
  static const fogNight = SkyPalette(Color(0xFF1E2433), Color(0xFF313A4B), Color(0xFF4A5568), Color(0xFF55607A), Color(0xFF262E42));
  static const stormDay = SkyPalette(Color(0xFF232A45), Color(0xFF343C5C), Color(0xFF4B5476), Color(0xFF6E7799), Color(0xFF2A3050));
  static const stormNight = SkyPalette(Color(0xFF0A0B1E), Color(0xFF1A1740), Color(0xFF2D2A66), Color(0xFF4C5488), Color(0xFF121631));

  // Clear-sky colour keyframes by sun altitude (-0.3 deep night .. 1.0 noon).
  static const List<double> _alts = [-0.30, -0.08, 0.0, 0.12, 0.35, 1.0];
  static const List<Color> _eveTop = [Color(0xFF070B24), Color(0xFF1B1F5C), Color(0xFF2F3A8C), Color(0xFF3B72C8), Color(0xFF2A6BD1), Color(0xFF1B56C4)];
  static const List<Color> _eveMid = [Color(0xFF141A4A), Color(0xFF5B3A86), Color(0xFFD9684F), Color(0xFF9DB6D8), Color(0xFF5E9BE6), Color(0xFF3F8CE6)];
  static const List<Color> _eveBot = [Color(0xFF2A2F78), Color(0xFFE0607E), Color(0xFFFFB36B), Color(0xFFFFC48A), Color(0xFFB6D8F5), Color(0xFF8EC8F7)];
  static const List<Color> _morTop = [Color(0xFF070B24), Color(0xFF1E2A66), Color(0xFF3A4F9E), Color(0xFF3B72C8), Color(0xFF2A6BD1), Color(0xFF1B56C4)];
  static const List<Color> _morMid = [Color(0xFF141A4A), Color(0xFF6A5AA8), Color(0xFFF0907A), Color(0xFF9DB6D8), Color(0xFF5E9BE6), Color(0xFF3F8CE6)];
  static const List<Color> _morBot = [Color(0xFF2A2F78), Color(0xFFF0A08A), Color(0xFFFFD08A), Color(0xFFFFD9A0), Color(0xFFB6D8F5), Color(0xFF8EC8F7)];

  // Sun light colour by altitude: moonlight -> magenta -> red -> orange -> gold -> white.
  static const List<double> _lightAlts = [-0.30, -0.10, 0.0, 0.06, 0.18, 0.40, 1.0];
  static const List<Color> _lightCols = [Color(0xFF6A74C8), Color(0xFFC8508C), Color(0xFFFF6A3D), Color(0xFFFF9A4D), Color(0xFFFFC866), Color(0xFFFFEFC4), Color(0xFFFFFAF0)];

  static Color _key(List<double> xs, List<Color> cs, double x) {
    if (x <= xs.first) return cs.first;
    for (var i = 1; i < xs.length; i++) {
      if (x <= xs[i]) {
        final t = (x - xs[i - 1]) / (xs[i] - xs[i - 1]);
        return Color.lerp(cs[i - 1], cs[i], t)!;
      }
    }
    return cs.last;
  }

  static Color sunLight(double alt, double morning) {
    final c = _key(_lightAlts, _lightCols, alt);
    return Color.lerp(c, const Color(0xFFFFB38A), cl(morning) * 0.2)!;
  }

  static SkyPalette _pair(SkyPalette day, SkyPalette night, double daylight) =>
      lerp(night, day, daylight);

  static SkyPalette build({
    required double cloud,
    required double rain,
    required double snow,
    required double fog,
    required double storm,
    required double alt,
    required double morning,
    required double warm,
  }) {
    final daylight = smooth(-0.12, 0.10, alt);
    final m = cl(morning);
    Color k(List<Color> eve, List<Color> mor) =>
        Color.lerp(_key(_alts, eve, alt), _key(_alts, mor, alt), m)!;

    var p = SkyPalette(
      k(_eveTop, _morTop),
      k(_eveMid, _morMid),
      k(_eveBot, _morBot),
      Color.lerp(clearNight.cloudLight, clearDay.cloudLight, daylight)!,
      Color.lerp(clearNight.cloudDark, clearDay.cloudDark, daylight)!,
    );
    p = lerp(p, _pair(overcastDay, overcastNight, daylight), cl(cloud));
    p = lerp(p, _pair(rainDay, rainNight, daylight), cl(rain * 2));
    p = lerp(p, _pair(snowDay, snowNight, daylight), cl(snow * 2));
    p = lerp(p, _pair(fogDay, fogNight, daylight), cl(fog));
    p = lerp(p, _pair(stormDay, stormNight, daylight), cl(storm * 1.5));

    final light = sunLight(alt, m);
    final block = cl(cloud * 0.55 + rain * 0.5 + snow * 0.4 + fog * 0.4 + storm * 0.6);
    final tint = cl(warm) * 0.28 * (1 - block * 0.5);
    return SkyPalette(
      p.top,
      Color.lerp(p.mid, light, tint * 0.8)!,
      Color.lerp(p.bottom, light, tint)!,
      Color.lerp(p.cloudLight, light, cl(warm) * 0.6)!,
      Color.lerp(p.cloudDark, const Color(0xFF5A4A78), cl(warm) * 0.3 * (1 - cl(storm)))!,
      light,
    );
  }
}
