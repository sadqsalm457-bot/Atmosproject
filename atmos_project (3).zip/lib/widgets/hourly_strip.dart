import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:intl/intl.dart' show DateFormat;

import '../state/app_scope.dart';
import '../theme/app_text.dart';
import 'weather_icons.dart';

class HourlyStrip extends StatelessWidget {
  const HourlyStrip({super.key});

  @override
  Widget build(BuildContext context) {
    final app = AppScope.of(context);
    final b = app.bundle;
    if (b == null) return const SizedBox.shrink();
    final hours = b.nextHours(24);
    final tf = DateFormat('HH:mm');
    return ClipRRect(
      borderRadius: BorderRadius.circular(28),
      child: BackdropFilter(
        filter: ui.ImageFilter.blur(sigmaX: 18, sigmaY: 18),
        child: Container(
          height: 118,
          decoration: BoxDecoration(
            color: Colors.white.withValues(alpha: 0.07),
            borderRadius: BorderRadius.circular(28),
            border: Border.all(color: Colors.white.withValues(alpha: 0.10), width: 1),
          ),
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
            itemCount: hours.length,
            separatorBuilder: (_, __) => const SizedBox(width: 6),
            itemBuilder: (context, i) {
              final h = hours[i];
              final first = i == 0;
              return Container(
                width: 60,
                padding: const EdgeInsets.symmetric(vertical: 8),
                decoration: BoxDecoration(
                  color: Colors.white.withValues(alpha: first ? 0.16 : 0.06),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(first ? app.tr('now') : tf.format(h.time),
                        style: AppText.style(size: 12, weight: FontWeight.w700, color: AppText.dim(0.75))),
                    WeatherIcon(
                        code: first ? b.current.code : h.code,
                        isDay: first ? b.current.isDay : h.isDay,
                        size: 30),
                    Text(app.settings.tempText(first ? b.current.temp : h.temp),
                        style: AppText.style(size: 16, weight: FontWeight.w800)),
                    SizedBox(
                      height: 12,
                      child: h.precipProb >= 30
                          ? Text('${h.precipProb.round()}%',
                              style: AppText.style(
                                  size: 10.5, weight: FontWeight.w700, color: const Color(0xFF8CC8FF)))
                          : null,
                    ),
                  ],
                ),
              );
            },
          ),
        ),
      ),
    );
  }
}
