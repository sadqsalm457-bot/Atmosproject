import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:intl/intl.dart' show DateFormat;

import '../state/app_scope.dart';
import '../theme/app_text.dart';
import '../util/math_utils.dart';
import 'aqi_pill.dart';
import 'details_painters.dart';
import 'glass.dart';
import 'ui_icons.dart';

class DetailsSheet extends StatelessWidget {
  const DetailsSheet({super.key, required this.controller, required this.onClose});

  final ScrollController controller;
  final VoidCallback onClose;

  Widget _anim(Widget Function(double v) build) => TweenAnimationBuilder<double>(
        tween: Tween<double>(begin: 0, end: 1),
        duration: const Duration(milliseconds: 1100),
        curve: Curves.easeOutCubic,
        builder: (context, v, _) => build(v),
      );

  @override
  Widget build(BuildContext context) {
    final app = AppScope.of(context);
    final b = app.bundle;
    if (b == null) return const SizedBox.shrink();
    final engine = AppScope.engineOf(context);
    final s = app.settings;
    final c = b.current;
    final today = b.today;
    final now = b.localNow;
    final tf = DateFormat('HH:mm');
    final pad = MediaQuery.paddingOf(context);

    final diff = c.feelsLike - c.temp;
    final feelsNote = diff.abs() < 1.5
        ? app.tr('feels_similar')
        : (diff > 0 ? app.tr('feels_warmer') : app.tr('feels_cooler'));

    final uvKey = c.uv < 3
        ? 'uv_low'
        : c.uv < 6
            ? 'uv_moderate'
            : c.uv < 8
                ? 'uv_high'
                : c.uv < 11
                    ? 'uv_very_high'
                    : 'uv_extreme';

    final visKm = c.visibility / 1000;
    final visText = visKm >= 10 ? visKm.toStringAsFixed(0) : visKm.toStringAsFixed(1);

    final dayLen = today.sunset.difference(today.sunrise).inSeconds;
    final sunP = dayLen <= 0 ? 0.0 : cl(now.difference(today.sunrise).inSeconds / dayLen);

    final hours = b.nextHours(24);
    var maxProb = 0.0;
    var sumMm = 0.0;
    for (final h in hours) {
      if (h.precipProb > maxProb) maxProb = h.precipProb;
      sumMm += h.precip;
    }
    final precipSum = app
        .tr('precip_sum')
        .replaceAll('{p}', maxProb.round().toString())
        .replaceAll('{mm}', sumMm.toStringAsFixed(1));

    final labels = [
      app.tr('compass_n'),
      app.tr('compass_e'),
      app.tr('compass_s'),
      app.tr('compass_w'),
    ];

    final air = b.air;

    return ClipRRect(
      borderRadius: const BorderRadius.vertical(top: Radius.circular(32)),
      child: BackdropFilter(
        filter: ui.ImageFilter.blur(sigmaX: 30, sigmaY: 30),
        child: Container(
          decoration: BoxDecoration(
            color: const Color(0xFF0E1330).withValues(alpha: 0.62),
            border: Border(top: BorderSide(color: Colors.white.withValues(alpha: 0.14), width: 1)),
          ),
          child: ListView(
            controller: controller,
            padding: EdgeInsets.fromLTRB(16, 10, 16, pad.bottom + 28),
            children: [
              Center(
                child: Container(
                  width: 44,
                  height: 5,
                  decoration: BoxDecoration(
                    color: Colors.white.withValues(alpha: 0.35),
                    borderRadius: BorderRadius.circular(3),
                  ),
                ),
              ),
              const SizedBox(height: 14),
              Row(
                children: [
                  Expanded(child: Text(app.tr('details'), style: AppText.style(size: 22, weight: FontWeight.w800))),
                  GlassButton(onTap: onClose, size: 38, child: const UiIcon(UiGlyph.close, size: 18)),
                ],
              ),
              const SizedBox(height: 14),
              Row(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Expanded(
                    child: _Tile(
                      title: app.tr('feels_like'),
                      height: 176,
                      child: _anim((v) => Stack(
                            alignment: Alignment.center,
                            children: [
                              CustomPaint(
                                size: Size.infinite,
                                painter: ArcGaugePainter(
                                  fraction: (c.feelsLike + 15) / 60,
                                  color: tempColor(c.feelsLike),
                                  progress: v,
                                  engine: engine,
                                ),
                              ),
                              Column(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Text(s.tempText(c.feelsLike), style: AppText.style(size: 32, weight: FontWeight.w800)),
                                  Text(feelsNote,
                                      textAlign: TextAlign.center,
                                      style: AppText.style(size: 11, weight: FontWeight.w600, color: AppText.dim(0.6))),
                                ],
                              ),
                            ],
                          )),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: _Tile(
                      title: app.tr('humidity'),
                      height: 176,
                      child: _anim((v) => Stack(
                            alignment: Alignment.center,
                            children: [
                              CustomPaint(
                                size: Size.infinite,
                                painter: WaterPainter(level: c.humidity / 100 * v, engine: engine),
                              ),
                              Text('${c.humidity}%', style: AppText.style(size: 28, weight: FontWeight.w800)),
                            ],
                          )),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Row(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Expanded(
                    child: _Tile(
                      title: app.tr('wind'),
                      height: 176,
                      child: _anim((v) => Stack(
                            alignment: Alignment.center,
                            children: [
                              CustomPaint(
                                size: Size.infinite,
                                painter: CompassPainter(
                                  dir: c.windDir,
                                  speed01: cl(c.windKmh / 60),
                                  progress: v,
                                  labels: labels,
                                  engine: engine,
                                ),
                              ),
                              Column(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Text(s.wind(c.windKmh).round().toString(),
                                      style: AppText.style(size: 26, weight: FontWeight.w800)),
                                  Text(s.windLabel,
                                      style: AppText.style(size: 11, weight: FontWeight.w600, color: AppText.dim(0.6))),
                                ],
                              ),
                            ],
                          )),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: _Tile(
                      title: app.tr('uv'),
                      height: 176,
                      child: _anim((v) => Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text('${c.uv.round()}', style: AppText.style(size: 32, weight: FontWeight.w800)),
                              Text(app.tr(uvKey),
                                  style: AppText.style(size: 13, weight: FontWeight.w700, color: AppText.dim(0.7))),
                              const Spacer(),
                              SizedBox(
                                height: 28,
                                child: CustomPaint(
                                  size: Size.infinite,
                                  painter: UvBarPainter(uv: c.uv, progress: v),
                                ),
                              ),
                            ],
                          )),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Row(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Expanded(
                    child: _Tile(
                      title: app.tr('pressure'),
                      height: 150,
                      child: _anim((v) => Stack(
                            alignment: Alignment.bottomCenter,
                            children: [
                              CustomPaint(
                                size: Size.infinite,
                                painter: PressurePainter(hpa: c.pressure, progress: v, engine: engine),
                              ),
                              Padding(
                                padding: const EdgeInsets.only(bottom: 14),
                                child: Text('${c.pressure.round()}',
                                    style: AppText.style(size: 20, weight: FontWeight.w800)),
                              ),
                            ],
                          )),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: _Tile(
                      title: app.tr('visibility'),
                      height: 150,
                      child: _anim((v) => Stack(
                            children: [
                              Positioned.fill(
                                child: CustomPaint(painter: MountainPainter(km: visKm, progress: v)),
                              ),
                              Text('$visText km', style: AppText.style(size: 22, weight: FontWeight.w800)),
                            ],
                          )),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              _Tile(
                title: app.tr('sun_path'),
                height: 190,
                child: Column(
                  children: [
                    Expanded(
                      child: _anim((v) => CustomPaint(
                            size: Size.infinite,
                            painter: SunArcPainter(p: sunP, progress: v, engine: engine),
                          )),
                    ),
                    const SizedBox(height: 6),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        _TimeLabel(label: app.tr('sunrise'), value: tf.format(today.sunrise)),
                        _TimeLabel(label: app.tr('sunset'), value: tf.format(today.sunset), end: true),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 12),
              _Tile(
                title: app.tr('precip'),
                height: 210,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(precipSum, style: AppText.style(size: 12.5, weight: FontWeight.w600, color: AppText.dim(0.75))),
                    const SizedBox(height: 8),
                    Expanded(
                      child: _anim((v) => CustomPaint(
                            size: Size.infinite,
                            painter: PrecipPainter(hours: hours, progress: v),
                          )),
                    ),
                    const SizedBox(height: 6),
                    if (hours.length > 1)
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          for (final i in [0, (hours.length * 0.33).floor(), (hours.length * 0.66).floor(), hours.length - 1])
                            Text(tf.format(hours[i].time),
                                style: AppText.style(size: 11, weight: FontWeight.w600, color: AppText.dim(0.55))),
                        ],
                      ),
                  ],
                ),
              ),
              const SizedBox(height: 12),
              if (air == null)
                _Tile(
                  title: app.tr('air_quality'),
                  height: 90,
                  child: Text(app.tr('aqi_unavailable'),
                      style: AppText.style(size: 13, weight: FontWeight.w500, color: AppText.dim(0.7))),
                )
              else
                _Tile(
                  title: app.tr('air_quality'),
                  child: Column(
                    children: [
                      SizedBox(
                        height: 150,
                        child: _anim((v) => Stack(
                              alignment: Alignment.bottomCenter,
                              children: [
                                CustomPaint(
                                  size: Size.infinite,
                                  painter: AqiGaugePainter(aqi: air.aqi, progress: v, engine: engine),
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(bottom: 6),
                                  child: Column(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      Text('${air.aqi}', style: AppText.style(size: 34, weight: FontWeight.w800)),
                                      Text(app.tr(aqiKey(air.aqi)),
                                          style: AppText.style(
                                              size: 12.5, weight: FontWeight.w700, color: aqiColor(air.aqi))),
                                    ],
                                  ),
                                ),
                              ],
                            )),
                      ),
                      const SizedBox(height: 10),
                      _pollutant('PM2.5', air.pm25, 75),
                      _pollutant('PM10', air.pm10, 150),
                      _pollutant('NO\u2082', air.no2, 200),
                      _pollutant('O\u2083', air.o3, 180),
                      _pollutant('SO\u2082', air.so2, 100),
                      _pollutant('CO', air.co, 10000),
                    ],
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _pollutant(String name, double value, double limit) {
    return SizedBox(
      height: 32,
      child: Row(
        textDirection: TextDirection.ltr,
        children: [
          SizedBox(width: 56, child: Text(name, style: AppText.style(size: 12.5, weight: FontWeight.w700, color: AppText.dim(0.8)))),
          Expanded(
            child: _anim((v) => CustomPaint(
                  size: const Size(double.infinity, 12),
                  painter: PollutantBarPainter(frac: value / limit, progress: v),
                )),
          ),
          SizedBox(
            width: 70,
            child: Text(
              value >= 100 ? value.toStringAsFixed(0) : value.toStringAsFixed(1),
              textAlign: TextAlign.end,
              style: AppText.style(size: 12.5, weight: FontWeight.w700),
            ),
          ),
        ],
      ),
    );
  }
}

class _TimeLabel extends StatelessWidget {
  const _TimeLabel({required this.label, required this.value, this.end = false});

  final String label;
  final String value;
  final bool end;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: end ? CrossAxisAlignment.end : CrossAxisAlignment.start,
      children: [
        Text(label, style: AppText.style(size: 11, weight: FontWeight.w600, color: AppText.dim(0.55))),
        Text(value, style: AppText.style(size: 15, weight: FontWeight.w800)),
      ],
    );
  }
}

class _Tile extends StatelessWidget {
  const _Tile({required this.title, required this.child, this.height});

  final String title;
  final Widget child;
  final double? height;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: height,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.07),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: Colors.white.withValues(alpha: 0.10), width: 1),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: height == null ? MainAxisSize.min : MainAxisSize.max,
        children: [
          Text(title, style: AppText.style(size: 12, weight: FontWeight.w700, color: AppText.dim(0.6), spacing: 0.4)),
          const SizedBox(height: 8),
          if (height != null) Expanded(child: child) else child,
        ],
      ),
    );
  }
}
