import 'package:flutter/material.dart';

import '../util/math_utils.dart';
import 'engine_controller.dart';
import 'layer.dart';
import 'sun_geometry.dart';

class FogPainter implements SceneLayer {
  final Paint _p = Paint();

  @override
  void paint(Canvas canvas, Size size, EngineController e) {
    final st = e.current;
    final f = st.fog;
    if (f < 0.02) return;
    final pal = st.palette;
    final w = size.width;
    final h = size.height;
    final rect = Offset.zero & size;
    final fogCol = Color.lerp(pal.cloudLight, pal.light, st.warm * 0.5)!;

    _p.shader = LinearGradient(
      begin: Alignment.topCenter,
      end: Alignment.bottomCenter,
      colors: [
        fogCol.withValues(alpha: f * 0.22),
        fogCol.withValues(alpha: f * 0.42),
      ],
    ).createShader(rect);
    canvas.drawRect(rect, _p);

    final above = smooth(-0.14, 0.03, st.sunAlt);
    if (above > 0.02) {
      final pos = sunPosition(st, size);
      final r = w * 0.8;
      _p.shader = RadialGradient(
        colors: [
          pal.light.withValues(alpha: f * (0.25 + 0.35 * st.warm) * above),
          pal.light.withValues(alpha: 0),
        ],
      ).createShader(Rect.fromCircle(center: pos, radius: r));
      canvas.drawCircle(pos, r, _p);
    }

    for (var i = 0; i < 6; i++) {
      final bw = w * (0.9 + 0.2 * (i % 3));
      final bh = h * 0.09;
      final span = w + bw * 2;
      final seed = hash01(i + 40);
      final x = ((seed * span + e.cloudScroll[i % 4] * 1.6) % span) - bw;
      final y = h * (0.22 + 0.11 * i);
      _p.shader = RadialGradient(
        colors: [
          fogCol.withValues(alpha: f * 0.30),
          fogCol.withValues(alpha: 0),
        ],
      ).createShader(const Rect.fromLTWH(-1, -1, 2, 2));
      canvas.save();
      canvas.translate(x + bw / 2, y);
      canvas.scale(bw / 2, bh);
      canvas.drawCircle(Offset.zero, 1.0, _p);
      canvas.restore();
    }
    _p.shader = null;
  }
}
