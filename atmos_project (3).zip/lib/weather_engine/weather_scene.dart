import 'package:flutter/material.dart';

import 'engine_controller.dart';
import 'layer.dart';
import 'lightning_painter.dart';
import 'rain_painter.dart';
import 'shader_painters.dart';
import 'sky_painter.dart';
import 'snow_painter.dart';
import 'star_painter.dart';
import 'sun_painter.dart';
import 'wind_painter.dart';

/// Paints every weather layer in one pass, driven by a single controller.
class ScenePainter extends CustomPainter {
  ScenePainter(this.engine) : super(repaint: engine);

  final EngineController engine;

  final List<SceneLayer> _layers = [
    SkyPainter(),
    StarPainter(),
    SunPainter(),
    ShaderCloudPainter(),
    LightningPainter(),
    ShaderFogPainter(),
    WindPainter(),
    SnowPainter(),
    RainPainter(),
  ];

  @override
  void paint(Canvas canvas, Size size) {
    for (final l in _layers) {
      l.paint(canvas, size, engine);
    }
  }

  @override
  bool shouldRepaint(covariant ScenePainter oldDelegate) => oldDelegate.engine != engine;
}

class WeatherScene extends StatelessWidget {
  const WeatherScene({super.key, required this.painter});

  final ScenePainter painter;

  @override
  Widget build(BuildContext context) {
    return RepaintBoundary(
      child: SizedBox.expand(
        child: CustomPaint(painter: painter, isComplex: true, willChange: true),
      ),
    );
  }
}
