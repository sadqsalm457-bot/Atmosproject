import 'dart:math' as math;
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';

import '../util/math_utils.dart';
import 'engine_controller.dart';
import 'layer.dart';

class RainPainter implements SceneLayer {
  RainPainter() {
    final r = math.Random(21);
    for (var i = 0; i < _max; i++) {
      _x0[i] = r.nextDouble();
      _y0[i] = r.nextDouble();
      _sj[i] = r.nextDouble();
      _lj[i] = r.nextDouble();
    }
  }

  static const int _max = 900;
  static const List<double> _speed = [0.75, 1.05, 1.5];
  static const List<double> _length = [14, 24, 40];
  static const List<double> _width = [0.8, 1.2, 1.8];
  static const List<double> _alpha = [0.22, 0.32, 0.46];
  static const Color _base = Color(0xFFD6E0FF);
  Color _tint = _base;

  final List<double> _x0 = List<double>.filled(_max, 0);
  final List<double> _y0 = List<double>.filled(_max, 0);
  final List<double> _sj = List<double>.filled(_max, 0);
  final List<double> _lj = List<double>.filled(_max, 0);
  final List<Float32List> _buf = [
    Float32List(_max * 4),
    Float32List(_max * 4),
    Float32List(_max * 4),
  ];
  final Paint _line = Paint()
    ..style = PaintingStyle.stroke
    ..strokeCap = StrokeCap.round;
  final Paint _fill = Paint()..style = PaintingStyle.fill;
  final Paint _veil = Paint();
  final Paint _ring = Paint()
    ..style = PaintingStyle.stroke
    ..strokeWidth = 1.0;

  @override
  void paint(Canvas canvas, Size size, EngineController e) {
    final st = e.current;
    final intensity = st.rain;
    if (intensity < 0.02) return;
    final w = size.width;
    final h = size.height;
    final n = math.min(_max, ((150 + 750 * intensity) * (e.reduceMotion ? 0.5 : 1.0)).round());
    final fade = cl(intensity * 4);
    _tint = Color.lerp(_base, st.palette.light, st.warm * 0.45)!;
    final vis = 0.6 + 0.4 * st.daylight + e.flash * 0.4;
    final rect = Offset.zero & size;
    _veil.shader = LinearGradient(
      begin: Alignment.topCenter,
      end: Alignment.bottomCenter,
      colors: [const Color(0x00000000), st.palette.bottom.withValues(alpha: cl(intensity) * 0.20)],
      stops: const [0.4, 1.0],
    ).createShader(rect);
    canvas.drawRect(rect, _veil);
    final angle = st.windDx * (0.10 + st.wind * 0.45);
    final dx = math.sin(angle);
    final dy = math.cos(angle);
    final slant = dx / dy;
    final splashY = h * e.splashFrac;
    final counts = <int>[0, 0, 0];

    for (var i = 0; i < n; i++) {
      final m = i % 10;
      final layer = m < 5 ? 0 : (m < 8 ? 1 : 2);
      final v = _speed[layer] * h * (0.85 + 0.3 * _sj[i]);
      final len = _length[layer] * (0.7 + 0.6 * _lj[i]) * (0.6 + 0.4 * intensity);
      double y;
      if (layer == 2) {
        const top = -60.0;
        final span = splashY - top;
        final period = span / v / 0.88;
        final ph = frac(_y0[i] + e.time / period);
        if (ph >= 0.88) {
          if (e.splashFrac < 1.02) {
            _splash(canvas, (_x0[i] * w + slant * splashY) % w, splashY, (ph - 0.88) / 0.12, fade * vis);
          }
          continue;
        }
        y = top + ph / 0.88 * span;
      } else {
        final period = (h + 120) / v;
        y = -60 + frac(_y0[i] + e.time / period) * (h + 120);
      }
      final x = (_x0[i] * w + slant * y) % w;
      final b = _buf[layer];
      final k = counts[layer] * 4;
      b[k] = x;
      b[k + 1] = y;
      b[k + 2] = x - dx * len;
      b[k + 3] = y - dy * len;
      counts[layer]++;
    }

    for (var l = 0; l < 3; l++) {
      if (counts[l] == 0) continue;
      _line
        ..strokeWidth = _width[l]
        ..color = _tint.withValues(alpha: _alpha[l] * fade * vis);
      canvas.drawRawPoints(
        ui.PointMode.lines,
        Float32List.sublistView(_buf[l], 0, counts[l] * 4),
        _line,
      );
    }
  }

  void _splash(Canvas c, double x, double y, double sp, double fade) {
    final a = (1 - sp) * 0.5 * fade;
    final r = 3 + 11 * sp;
    _ring.color = _tint.withValues(alpha: a);
    c.drawOval(Rect.fromCenter(center: Offset(x, y), width: r * 2.6, height: r * 0.8), _ring);
    _fill.color = _tint.withValues(alpha: a);
    final up = 12 * math.sin(math.pi * sp);
    c.drawCircle(Offset(x - r * 0.9, y - up), 1.1, _fill);
    c.drawCircle(Offset(x + r * 0.9, y - up * 0.8), 1.1, _fill);
  }
}
