import 'package:flutter/material.dart';

import '../util/math_utils.dart';
import 'engine_controller.dart';
import 'layer.dart';

class SkyPainter implements SceneLayer {
  final Paint _p = Paint();

  @override
  void paint(Canvas canvas, Size size, EngineController e) {
    final st = e.current;
    final pal = st.palette;
    var top = pal.top;
    var mid = pal.mid;
    var bot = pal.bottom;
    if (e.flash > 0.01 && st.storm > 0.1) {
      final k = e.flash * 0.30 * cl(st.storm);
      const fl = Color(0xFF8E9CFF);
      top = Color.lerp(top, fl, k)!;
      mid = Color.lerp(mid, fl, k)!;
      bot = Color.lerp(bot, fl, k)!;
    }
    final rect = Offset.zero & size;
    _p.shader = LinearGradient(
      begin: Alignment.topCenter,
      end: Alignment.bottomCenter,
      colors: [top, mid, bot],
      stops: const [0.0, 0.55, 1.0],
    ).createShader(rect);
    canvas.drawRect(rect, _p);

    _p.shader = const LinearGradient(
      begin: Alignment.topCenter,
      end: Alignment.bottomCenter,
      colors: [Color(0x00000000), Color(0x47000000)],
      stops: [0.5, 1.0],
    ).createShader(rect);
    canvas.drawRect(rect, _p);
    _p.shader = null;
  }
}
