import 'dart:math' as math;
import 'dart:ui' as ui;

import 'package:flutter/material.dart';

import '../util/math_utils.dart';
import 'engine_controller.dart';
import 'layer.dart';
import 'sun_geometry.dart';

/// Photo-like sun (limb-darkened disk, corona, light shafts, lens flare,
/// horizon glow) and a shaded moon. Colours follow the real sun altitude.
class SunPainter implements SceneLayer {
  final Paint _p = Paint();
  final Paint _beam = Paint();

  static const List<List<double>> _craters = [
    [-0.30, -0.20, 0.22],
    [0.25, 0.10, 0.28],
    [-0.05, 0.38, 0.18],
    [0.38, -0.32, 0.14],
    [-0.42, 0.20, 0.12],
  ];

  void _ellipse(Canvas c, Offset ctr, double rx, double ry, List<Color> colors, List<double> stops) {
    _p.shader = RadialGradient(colors: colors, stops: stops)
        .createShader(const Rect.fromLTWH(-1, -1, 2, 2));
    c.save();
    c.translate(ctr.dx, ctr.dy);
    c.scale(rx, ry);
    c.drawCircle(Offset.zero, 1.0, _p);
    c.restore();
    _p.shader = null;
  }

  @override
  void paint(Canvas canvas, Size size, EngineController e) {
    final st = e.current;
    final w = size.width;
    final h = size.height;
    final t = e.time;
    final alt = st.sunAlt;
    final pal = st.palette;
    final light = pal.light;
    final warm = st.warm;
    final clear = 1 - st.cloud;
    final block = (1 - st.rain * 0.75) * (1 - st.fog * 0.4) * (1 - st.storm * 0.8) * (1 - st.snow * 0.5);
    final above = smooth(-0.14, 0.03, alt);
    final glowA = above * (0.30 + 0.70 * clear) * block;
    final discVis = smooth(-0.02, 0.05, alt) * clear * clear * (1 - st.rain) * (1 - st.fog) * (1 - st.snow) * (1 - st.storm);
    final pos = sunPosition(st, size);

    if (glowA > 0.02) {
      _ellipse(
        canvas,
        Offset(pos.dx, h * 0.34),
        w * 0.95,
        h * 0.13,
        [
          light.withValues(alpha: glowA * warm * 0.55),
          light.withValues(alpha: glowA * warm * 0.18),
          light.withValues(alpha: 0),
        ],
        const [0.0, 0.45, 1.0],
      );
      final r = w * (0.62 + 0.25 * warm);
      _p.shader = RadialGradient(
        colors: [
          light.withValues(alpha: glowA * 0.65),
          light.withValues(alpha: glowA * 0.22),
          light.withValues(alpha: 0),
        ],
        stops: const [0.0, 0.3, 1.0],
      ).createShader(Rect.fromCircle(center: pos, radius: r));
      canvas.drawCircle(pos, r, _p);
      _p.shader = null;
    }

    if (!e.reduceMotion && (discVis > 0.05 || (glowA > 0.15 && warm > 0.25))) {
      final amt = math.max(discVis * 0.16, glowA * warm * 0.12);
      const n = 12;
      final base = t * 0.03;
      for (var i = 0; i < n; i++) {
        final a = base + i * math.pi * 2 / n + hash01(i) * 0.3;
        final len = w * (0.55 + 0.35 * hash01(i + 9));
        final half = 0.035 + 0.03 * hash01(i + 21);
        final breathe = 0.6 + 0.4 * math.sin(t * 0.6 + i * 1.3);
        final tip = pos + Offset(math.cos(a), math.sin(a)) * len;
        final l = pos + Offset(math.cos(a - half), math.sin(a - half)) * len;
        final r = pos + Offset(math.cos(a + half), math.sin(a + half)) * len;
        final path = Path()
          ..moveTo(pos.dx, pos.dy)
          ..lineTo(l.dx, l.dy)
          ..lineTo(r.dx, r.dy)
          ..close();
        _beam.shader = ui.Gradient.linear(
          pos,
          tip,
          [light.withValues(alpha: amt * breathe), light.withValues(alpha: 0)],
        );
        canvas.drawPath(path, _beam);
      }
      _beam.shader = null;
    }

    if (discVis > 0.02) {
      final mag = 1 - cl(alt / 0.5);
      final rad = (30 + 14 * mag) * (1 + 0.012 * math.sin(t * 1.3));
      final hot = Color.lerp(Colors.white, light, 0.30)!;
      final edge = Color.lerp(light, const Color(0xFFFF4D1F), warm * 0.55)!;

      _p.shader = RadialGradient(
        colors: [
          light.withValues(alpha: discVis * 0.55),
          light.withValues(alpha: discVis * 0.12),
          light.withValues(alpha: 0),
        ],
        stops: const [0.4, 0.62, 1.0],
      ).createShader(Rect.fromCircle(center: pos, radius: rad * 3.2));
      canvas.drawCircle(pos, rad * 3.2, _p);

      _p.shader = RadialGradient(
        colors: [
          hot.withValues(alpha: discVis),
          Color.lerp(hot, edge, 0.5)!.withValues(alpha: discVis),
          edge.withValues(alpha: discVis),
        ],
        stops: const [0.0, 0.62, 1.0],
      ).createShader(Rect.fromCircle(center: pos, radius: rad));
      canvas.drawCircle(pos, rad, _p);

      canvas.save();
      canvas.clipPath(Path()..addOval(Rect.fromCircle(center: pos, radius: rad)));
      for (var i = 0; i < 4; i++) {
        final c = pos + Offset(math.cos(t * 0.15 + i * 1.7), math.sin(t * 0.12 + i * 2.3)) * (rad * 0.45);
        _p.shader = RadialGradient(
          colors: [edge.withValues(alpha: discVis * 0.28), edge.withValues(alpha: 0)],
        ).createShader(Rect.fromCircle(center: c, radius: rad * 0.55));
        canvas.drawCircle(c, rad * 0.55, _p);
      }
      canvas.restore();
      _p.shader = null;

      if (!e.reduceMotion && alt > 0.08) {
        final ctr = Offset(w / 2, h * 0.55);
        const ks = [0.35, 0.62, 0.9, 1.25];
        const rs = [16.0, 26.0, 11.0, 34.0];
        for (var i = 0; i < 4; i++) {
          final c = pos + (ctr - pos) * ks[i];
          _p.shader = RadialGradient(
            colors: [light.withValues(alpha: discVis * 0.10), light.withValues(alpha: 0)],
          ).createShader(Rect.fromCircle(center: c, radius: rs[i]));
          canvas.drawCircle(c, rs[i], _p);
        }
        _p.shader = null;
      }
    }

    final night = smooth(0.0, -0.15, alt);
    final moonA = night * (1 - st.cloud * 0.85) * (1 - st.fog) * (1 - st.rain) * (1 - st.snow * 0.7) * (1 - st.storm);
    if (moonA > 0.02) {
      final mp = moonPosition(st, size);
      const r = 26.0;
      _p.shader = RadialGradient(
        colors: [
          const Color(0xFFC9D2FF).withValues(alpha: moonA * 0.30),
          const Color(0xFFC9D2FF).withValues(alpha: 0),
        ],
      ).createShader(Rect.fromCircle(center: mp, radius: r * 5));
      canvas.drawCircle(mp, r * 5, _p);

      final disk = Rect.fromCircle(center: mp, radius: r);
      _p.shader = RadialGradient(
        center: const Alignment(-0.35, -0.35),
        radius: 0.95,
        colors: [
          const Color(0xFFFFFDF2).withValues(alpha: moonA),
          const Color(0xFFE4E7F5).withValues(alpha: moonA),
          const Color(0xFFB4BBD6).withValues(alpha: moonA),
        ],
      ).createShader(disk);
      canvas.drawCircle(mp, r, _p);

      canvas.save();
      canvas.clipPath(Path()..addOval(disk));
      for (final c in _craters) {
        final cc = mp + Offset(c[0], c[1]) * r;
        _p.shader = RadialGradient(
          colors: [
            const Color(0xFF8F97BB).withValues(alpha: moonA * 0.35),
            const Color(0xFF8F97BB).withValues(alpha: 0),
          ],
        ).createShader(Rect.fromCircle(center: cc, radius: r * c[2] * 1.6));
        canvas.drawCircle(cc, r * c[2] * 1.6, _p);
      }
      _p.shader = RadialGradient(
        center: const Alignment(-0.5, -0.4),
        radius: 1.15,
        colors: [
          const Color(0x00050A22),
          const Color(0x00050A22),
          const Color(0xFF050A22).withValues(alpha: moonA * 0.5),
        ],
        stops: const [0.0, 0.55, 1.0],
      ).createShader(disk);
      canvas.drawCircle(mp, r, _p);
      canvas.restore();
      _p.shader = null;
    }
  }
}
