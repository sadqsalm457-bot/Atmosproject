import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../util/math_utils.dart';
import 'engine_controller.dart';
import 'layer.dart';
import 'sun_geometry.dart';

class _Puff {
  const _Puff(this.dx, this.dy, this.r);
  final double dx;
  final double dy;
  final double r;
}

class _Cloud {
  const _Cloud(this.x, this.y, this.scale, this.thr, this.puffs);
  final double x;
  final double y;
  final double scale;
  final double thr;
  final List<_Puff> puffs;
}

/// Volumetric-looking cumulus: every puff is shaded towards the real light
/// source (sun or moon), with a dark flat base and a warm rim at dawn/dusk.
class CloudPainter implements SceneLayer {
  CloudPainter() {
    final rnd = math.Random(5);
    for (var l = 0; l < 4; l++) {
      final list = <_Cloud>[];
      for (var i = 0; i < 6; i++) {
        final puffs = <_Puff>[];
        final np = 7 + rnd.nextInt(3);
        for (var k = 0; k < np; k++) {
          final t = k / (np - 1);
          final bump = math.sin(t * math.pi);
          puffs.add(_Puff(
            (t - 0.5) * 1.0,
            -bump * 0.12 + (rnd.nextDouble() - 0.5) * 0.05,
            0.15 + bump * 0.12 + rnd.nextDouble() * 0.05,
          ));
        }
        for (var k = 0; k < 3; k++) {
          puffs.add(_Puff(
            (rnd.nextDouble() - 0.5) * 0.5,
            -0.14 - rnd.nextDouble() * 0.08,
            0.12 + rnd.nextDouble() * 0.08,
          ));
        }
        puffs.sort((a, b) => b.dy.compareTo(a.dy));
        list.add(_Cloud(
          rnd.nextDouble(),
          0.04 + rnd.nextDouble() * 0.28,
          0.8 + rnd.nextDouble() * 0.5,
          (i + 0.5) / 6 * 0.9,
          puffs,
        ));
      }
      _layers.add(list);
    }
  }

  final List<List<_Cloud>> _layers = [];
  final Paint _body = Paint();
  final Paint _base = Paint();
  final Paint _rim = Paint();
  static const Rect _unit = Rect.fromLTWH(-1, -1, 2, 2);

  @override
  void paint(Canvas canvas, Size size, EngineController e) {
    final st = e.current;
    final cover = st.cloud;
    if (cover < 0.03) return;
    final pal = st.palette;
    final alt = st.sunAlt;
    final w = size.width;
    final h = size.height;
    final dark = cl(0.15 * cover + 0.75 * math.max(st.rain, st.storm));

    final useSun = alt > -0.08;
    final lp = useSun ? sunPosition(st, size) : moonPosition(st, size);
    final ls = useSun ? smooth(-0.14, 0.05, alt) : 0.35 * smooth(0.0, -0.15, alt);
    final f = cl(e.flash);

    for (var l = 0; l < 4; l++) {
      final depth = l / 3.0;
      final haze = (1 - depth) * 0.3;

      var shade = Color.lerp(Color.lerp(pal.cloudDark, pal.top, 0.25)!, const Color(0xFF2A2F55), dark * 0.6)!;
      var lit = Color.lerp(pal.cloudLight, pal.light, st.warm * 0.8 * ls)!;
      lit = Color.lerp(lit, Colors.white, 0.12 * ls * (1 - dark))!;
      lit = Color.lerp(lit, shade, dark * 0.55)!;
      var mid = Color.lerp(lit, shade, 0.5)!;
      lit = Color.lerp(lit, pal.mid, haze)!;
      mid = Color.lerp(mid, pal.mid, haze)!;
      shade = Color.lerp(shade, pal.mid, haze)!;
      lit = Color.lerp(lit, const Color(0xFFE6EAFF), f * 0.85)!;
      mid = Color.lerp(mid, const Color(0xFFB9C4FF), f * 0.7)!;
      shade = Color.lerp(shade, const Color(0xFF8C98E0), f * 0.5)!;

      final baseA = (0.40 + 0.16 * l) * (0.55 + 0.45 * cover);
      final cw = w * (0.55 + 0.17 * l);
      final span = w + cw * 3.2;
      final scroll = e.cloudScroll[l];
      final rimOn = st.warm * ls > 0.12;

      for (final cloud in _layers[l]) {
        final a = cl((cover - cloud.thr) / 0.25) * baseA;
        if (a < 0.02) continue;
        final cwi = cw * cloud.scale;
        final cx = ((cloud.x * span + scroll) % span) - cw * 1.6;
        final cy = h * (cloud.y + 0.02 * l);

        var d = lp - Offset(cx, cy);
        final len = d.distance;
        d = len < 1 ? const Offset(0, -1) : d / len;
        final ax = d.dx * 0.5;
        final ay = cl(d.dy * 0.5 - 0.15, -0.6, 0.6);

        _body.shader = RadialGradient(
          center: Alignment(ax, ay),
          radius: 0.55,
          colors: [
            lit.withValues(alpha: a),
            mid.withValues(alpha: a * 0.92),
            shade.withValues(alpha: a * 0.72),
            shade.withValues(alpha: 0),
          ],
          stops: const [0.0, 0.42, 0.78, 1.0],
        ).createShader(_unit);

        _base.shader = RadialGradient(
          colors: [shade.withValues(alpha: a * 0.40), shade.withValues(alpha: 0)],
        ).createShader(_unit);
        canvas.save();
        canvas.translate(cx, cy + cwi * 0.09);
        canvas.scale(cwi * 0.5, cwi * 0.07);
        canvas.drawCircle(Offset.zero, 1.0, _base);
        canvas.restore();

        if (rimOn) {
          _rim.shader = RadialGradient(
            center: Alignment(d.dx * 0.75, d.dy * 0.75),
            radius: 0.4,
            colors: [
              pal.light.withValues(alpha: a * st.warm * ls * 0.75),
              pal.light.withValues(alpha: 0),
            ],
          ).createShader(_unit);
        }

        for (final pf in cloud.puffs) {
          final r = pf.r * cwi;
          canvas.save();
          canvas.translate(cx + pf.dx * cwi, cy + pf.dy * cwi);
          canvas.scale(r * 1.5, r);
          canvas.drawCircle(Offset.zero, 1.0, _body);
          if (rimOn) canvas.drawCircle(Offset.zero, 1.0, _rim);
          canvas.restore();
        }
      }
    }
    _body.shader = null;
    _base.shader = null;
    _rim.shader = null;
  }
}
