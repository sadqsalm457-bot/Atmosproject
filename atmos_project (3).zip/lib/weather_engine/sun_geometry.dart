import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../util/math_utils.dart';
import 'engine_state.dart';

/// Sun position on screen: rises on the left, peaks high, sets on the right.
Offset sunPosition(EngineState st, Size s) => Offset(
      s.width * (0.22 + 0.62 * st.sunP),
      s.height * (0.31 - 0.24 * cl(st.sunAlt, -0.3, 1.0)),
    );

Offset moonPosition(EngineState st, Size s) => Offset(
      s.width * (0.22 + 0.62 * st.celest),
      s.height * (0.31 - 0.22 * math.sin(math.pi * st.celest)),
    );
