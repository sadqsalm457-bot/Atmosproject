import 'dart:math' as math;
import 'dart:ui' as ui;

import 'package:flutter/material.dart';

import '../util/math_utils.dart';
import 'cloud_painter.dart';
import 'engine_controller.dart';
import 'fog_painter.dart';
import 'layer.dart';
import 'sun_geometry.dart';

/// Shared uniform upload for shaders/clouds.frag (order must match the file).
void _upload(
  ui.FragmentShader sh, {
  required Size size,
  required EngineController e,
  required double cover,
  required double dark,
  required double mode,
  required Offset sun,
  required double sunStr,
  required double warm,
  required double flash,
  required double quality,
  required Color lit,
  required Color shade,
  required Color light,
  required Color haze,
  required double scrollX,
}) {
  var i = 0;
  void f(double v) => sh.setFloat(i++, v);
  f(size.width);
  f(size.height);
  f(e.time);
  f(scrollX);
  f(0);
  f(cover);
  f(dark);
  f(mode);
  f(sun.dx);
  f(sun.dy);
  f(sunStr);
  f(warm);
  f(flash);
  f(quality);
  for (final c in [lit, shade, light, haze]) {
    f(c.r);
    f(c.g);
    f(c.b);
  }
}

/// Photographic clouds drawn per pixel with fractal noise on the GPU.
class ShaderCloudPainter implements SceneLayer {
  final CloudPainter _fallback = CloudPainter();
  final Paint _paint = Paint();
  ui.FragmentProgram? _prog;
  ui.FragmentShader? _shader;

  @override
  void paint(Canvas canvas, Size size, EngineController e) {
    final prog = e.program;
    if (prog == null) {
      _fallback.paint(canvas, size, e);
      return;
    }
    final st = e.current;
    final cover = st.cloud;
    if (cover < 0.03) return;
    try {
      if (!identical(prog, _prog)) {
        _prog = prog;
        _shader = prog.fragmentShader();
      }
      final sh = _shader!;
      final pal = st.palette;
      final alt = st.sunAlt;
      final useSun = alt > -0.08;
      final lp = useSun ? sunPosition(st, size) : moonPosition(st, size);
      final ls = useSun ? smooth(-0.14, 0.05, alt) : 0.35 * smooth(0.0, -0.15, alt);
      final dark = cl(math.max(st.rain, st.storm) * 0.9);

      var shade = Color.lerp(
        Color.lerp(pal.cloudDark, pal.top, 0.25)!,
        const Color(0xFF2A2F55),
        dark * 0.6,
      )!;
      var lit = Color.lerp(pal.cloudLight, pal.light, st.warm * 0.8 * ls)!;
      lit = Color.lerp(lit, Colors.white, 0.10 * ls * (1 - dark))!;
      lit = Color.lerp(lit, shade, dark * 0.5)!;
      shade = Color.lerp(shade, pal.mid, 0.12)!;

      final q = e.reduceMotion ? math.min(e.quality, 1.0) : e.quality;
      _upload(
        sh,
        size: size,
        e: e,
        cover: cover,
        dark: dark,
        mode: 0,
        sun: Offset(lp.dx / size.width, lp.dy / size.height),
        sunStr: ls,
        warm: st.warm,
        flash: e.flash * (e.reduceMotion ? 0.3 : 1.0),
        quality: q,
        lit: lit,
        shade: shade,
        light: pal.light,
        haze: pal.mid,
        scrollX: e.cloudScroll[1] / size.width * 0.6,
      );
      _paint.shader = sh;
      canvas.drawRect(Rect.fromLTWH(0, 0, size.width, size.height * 0.74), _paint);
    } catch (_) {
      e.program = null;
    }
  }
}

/// Soft drifting ground fog / mist using the same shader.
class ShaderFogPainter implements SceneLayer {
  final FogPainter _fallback = FogPainter();
  final Paint _paint = Paint();
  ui.FragmentProgram? _prog;
  ui.FragmentShader? _shader;

  @override
  void paint(Canvas canvas, Size size, EngineController e) {
    final prog = e.program;
    if (prog == null) {
      _fallback.paint(canvas, size, e);
      return;
    }
    final st = e.current;
    if (st.fog < 0.02) return;
    try {
      if (!identical(prog, _prog)) {
        _prog = prog;
        _shader = prog.fragmentShader();
      }
      final sh = _shader!;
      final pal = st.palette;
      final lp = sunPosition(st, size);
      final above = smooth(-0.14, 0.03, st.sunAlt);
      _upload(
        sh,
        size: size,
        e: e,
        cover: st.fog,
        dark: 0,
        mode: 1,
        sun: Offset(lp.dx / size.width, lp.dy / size.height),
        sunStr: above,
        warm: st.warm,
        flash: e.flash * 0.5,
        quality: math.min(e.quality, 1.0),
        lit: Color.lerp(pal.cloudLight, pal.light, st.warm * 0.5)!,
        shade: pal.cloudDark,
        light: pal.light,
        haze: Color.lerp(pal.cloudLight, pal.mid, 0.3)!,
        scrollX: e.cloudScroll[2] / size.width * 0.5,
      );
      _paint.shader = sh;
      canvas.drawRect(Offset.zero & size, _paint);
    } catch (_) {
      e.program = null;
    }
  }
}
