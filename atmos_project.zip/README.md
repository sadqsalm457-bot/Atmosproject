# Atmos - تطبيق طقس ذكي بسماء متحركة

تطبيق أندرويد (Flutter) بسماء كاملة متحركة تتغير مع الطقس الحقيقي: غيوم متعددة الطبقات، مطر، برق، ثلج، ضباب، نجوم وشهب، شمس وقمر. بيانات الطقس من Open-Meteo (بدون مفتاح)، مع بطاقة رؤى ذكية تعمل بمفتاح Claude الخاص بك أو بمولّد محلي.

كل شيء يتم من المتصفح في الهاتف دون أي أمر محلي. نسخة Flutter المثبتة: **3.35.0** (Dart 3.9) و Java 17.

## الخطوات من الهاتف فقط

### 1) إنشاء مستودع على GitHub
1. افتح github.com من متصفح الهاتف (يُفضّل تفعيل "موقع سطح المكتب" من قائمة المتصفح).
2. اضغط **+** ثم **New repository**.
3. اكتب اسماً مثل `atmos-weather` واختر **Private** أو **Public** ثم **Create repository**.

### 2) رفع المشروع
الطريقة الأسهل: رفع ملف الـ zip كما هو، والـ workflow يفكّ ضغطه تلقائياً.
1. داخل المستودع: **Add file** ثم **Upload files**.
2. اختر الملف `atmos_project.zip` من هاتفك (لا تفكّ ضغطه).
3. اضغط **Commit changes**.

### 3) إنشاء ملف الـ workflow (ملف واحد فقط يُكتب يدوياً)
1. **Add file** ثم **Create new file**.
2. في خانة الاسم اكتب بالضبط: `.github/workflows/build.yml` (عند كتابة `/` تُنشأ المجلدات تلقائياً).
3. الصق محتوى الملف `build.yml` (هو نفسه داخل الـ zip في نفس المسار، وموجود أدناه).
4. اضغط **Commit changes**.

```yaml
name: Build Atmos APK

on:
  push:
  workflow_dispatch:

jobs:
  build:
    runs-on: ubuntu-latest
    timeout-minutes: 45
    steps:
      - name: Checkout
        uses: actions/checkout@v4

      - name: Unpack project archive (only when uploaded as a zip)
        run: |
          if [ ! -f pubspec.yaml ]; then
            ZIP="$(ls ./*.zip 2>/dev/null | head -n 1 || true)"
            if [ -z "$ZIP" ]; then
              echo "No pubspec.yaml and no .zip found in the repository root."
              exit 1
            fi
            unzip -o -q "$ZIP"
          fi

      - name: Setup Java 17
        uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: "17"

      - name: Setup Flutter (pinned)
        uses: subosito/flutter-action@v2
        with:
          channel: stable
          flutter-version: "3.35.0"
          cache: true

      - name: Flutter version
        run: flutter --version

      - name: Generate android/ folder
        run: flutter create --platforms=android --org com.atmos --project-name atmos_weather .

      - name: Remove template test
        run: rm -f test/widget_test.dart

      - name: Patch Android project
        run: python3 tools/patch_android.py

      - name: Get packages
        run: flutter pub get

      - name: Build release APK
        run: flutter build apk --release

      - name: Upload APK
        uses: actions/upload-artifact@v4
        with:
          name: atmos-apk
          path: build/app/outputs/flutter-apk/app-release.apk
          if-no-files-found: error
```

### 4) تشغيل البناء
1. بعد الـ Commit يبدأ البناء تلقائياً. أو افتح تبويب **Actions** ثم **Build Atmos APK** ثم **Run workflow**.
2. انتظر 6 إلى 12 دقيقة حتى تظهر علامة صح خضراء.

### 5) تنزيل الـ APK
1. افتح التشغيل الناجح من تبويب **Actions**.
2. انزل إلى قسم **Artifacts** واضغط **atmos-apk** (ينزل ملف zip فيه `app-release.apk`).
3. فك الضغط من تطبيق الملفات في هاتفك.

### 6) التثبيت على هاتف Xiaomi (HyperOS)
1. اضغط على `app-release.apk`.
2. عند ظهور تحذير المصدر غير المعروف اسمح لتطبيق الملفات أو المتصفح بالتثبيت من هذا المصدر.
3. اضغط **تثبيت** ثم افتح **Atmos** واسمح بإذن الموقع.

## الإعدادات داخل التطبيق
- وحدة الحرارة C/F، وحدة الرياح (km/h, m/s, mph).
- اللغة: English أو العربية (مع اتجاه RTL كامل).
- **مفتاح Claude API**: الصقه في الإعدادات ليعمل الذكاء الاصطناعي (النموذج `claude-sonnet-4-6`). يُحفظ على هاتفك فقط. بدون مفتاح، أو عند فشل الاتصال، تعمل الرؤى بمولّد محلي ذكي.

## إذا فشل البناء
افتح التشغيل الفاشل في **Actions** وانسخ آخر 30 سطراً من الخطوة الحمراء وأرسلها لي لأصلحها.

## هيكل المشروع
- `lib/weather_engine/` محرك الطقس (سماء، نجوم، شمس/قمر، غيوم، ضباب، رياح، ثلج، مطر، برق) بـ Ticker واحد.
- `lib/widgets/` البطاقات الزجاجية، الأيقونات المرسومة، لوحة التفاصيل.
- `lib/services/` الطقس، الموقع، الذكاء الاصطناعي، التخزين.
- `tools/patch_android.py` يضيف الأذونات واسم التطبيق والأيقونة ويضبط minSdk 26.
- `android_overlay/res/` أيقونة التطبيق (XML فقط).
