import 'dart:async';

import 'package:flutter/material.dart';

import '../models/weather_models.dart';
import '../services/weather_service.dart';
import '../state/app_scope.dart';
import '../theme/app_text.dart';
import '../widgets/glass.dart';
import '../widgets/ui_icons.dart';

class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  final TextEditingController _c = TextEditingController();
  Timer? _deb;
  List<CityPlace> _res = const [];
  bool _busy = false;
  bool _failed = false;
  int _gen = 0;

  @override
  void dispose() {
    _deb?.cancel();
    _c.dispose();
    super.dispose();
  }

  void _onChanged(String q) {
    _deb?.cancel();
    final t = q.trim();
    if (t.length < 2) {
      _gen++;
      setState(() {
        _res = const [];
        _busy = false;
        _failed = false;
      });
      return;
    }
    _deb = Timer(const Duration(milliseconds: 350), () => _search(t));
  }

  Future<void> _search(String q) async {
    final gen = ++_gen;
    final lang = AppScope.of(context).lang;
    setState(() {
      _busy = true;
      _failed = false;
    });
    try {
      final r = await WeatherService.search(q, lang);
      if (!mounted || gen != _gen) return;
      setState(() {
        _res = r;
        _busy = false;
      });
    } catch (_) {
      if (!mounted || gen != _gen) return;
      setState(() {
        _busy = false;
        _failed = true;
      });
    }
  }

  Future<void> _pick(CityPlace p) async {
    final app = AppScope.of(context);
    final nav = Navigator.of(context);
    await app.addCity(p);
    nav.pop();
    await app.selectPlace(p);
  }

  Future<void> _gps() async {
    final app = AppScope.of(context);
    final nav = Navigator.of(context);
    nav.pop();
    await app.selectPlace(null);
  }

  @override
  Widget build(BuildContext context) {
    final app = AppScope.of(context);
    final pad = MediaQuery.paddingOf(context);
    final querying = _c.text.trim().length >= 2;

    final children = <Widget>[];
    if (querying) {
      if (_busy) {
        children.add(_hint(app.tr('searching')));
      } else if (_failed) {
        children.add(_hint(app.tr('search_failed')));
      } else if (_res.isEmpty) {
        children.add(_hint(app.tr('no_results')));
      } else {
        for (final p in _res) {
          children.add(_CityTile(
            title: p.name,
            subtitle: p.subtitle,
            onTap: () => _pick(p),
            trailing: const UiIcon(UiGlyph.plus, size: 20),
          ));
        }
      }
    } else {
      children.add(_CityTile(
        title: app.tr('use_gps'),
        subtitle: app.tr('use_gps_sub'),
        leading: const UiIcon(UiGlyph.pin, size: 22),
        onTap: _gps,
      ));
      if (app.saved.isNotEmpty) {
        children.add(Padding(
          padding: const EdgeInsets.fromLTRB(6, 18, 6, 8),
          child: Text(app.tr('saved'),
              style: AppText.style(size: 13, weight: FontWeight.w700, color: AppText.dim(0.65))),
        ));
        for (final p in app.saved) {
          children.add(_CityTile(
            title: p.name,
            subtitle: p.subtitle,
            onTap: () => _pick(p),
            trailing: GestureDetector(
              behavior: HitTestBehavior.opaque,
              onTap: () => app.removeCity(p),
              child: const Padding(
                padding: EdgeInsets.all(6),
                child: UiIcon(UiGlyph.trash, size: 20),
              ),
            ),
          ));
        }
      }
    }

    return Scaffold(
      backgroundColor: Colors.transparent,
      body: Padding(
        padding: EdgeInsets.fromLTRB(16, pad.top + 10, 16, 0),
        child: Column(
          children: [
            Row(
              children: [
                GlassButton(
                  onTap: () => Navigator.of(context).pop(),
                  child: const UiIcon(UiGlyph.back, size: 20),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Glass(
                    radius: 22,
                    blur: 20,
                    padding: const EdgeInsets.symmetric(horizontal: 14),
                    child: Row(
                      children: [
                        const UiIcon(UiGlyph.search, size: 18),
                        const SizedBox(width: 10),
                        Expanded(
                          child: TextField(
                            controller: _c,
                            autofocus: true,
                            onChanged: _onChanged,
                            cursorColor: AppText.ink,
                            style: AppText.style(size: 16, weight: FontWeight.w600),
                            decoration: InputDecoration(
                              border: InputBorder.none,
                              hintText: app.tr('search_hint'),
                              hintStyle: AppText.style(size: 16, weight: FontWeight.w500, color: AppText.dim(0.5)),
                              contentPadding: const EdgeInsets.symmetric(vertical: 14),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 14),
            Expanded(
              child: ListView(
                padding: EdgeInsets.only(bottom: pad.bottom + 24),
                children: children,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _hint(String t) => Padding(
        padding: const EdgeInsets.all(24),
        child: Center(
          child: Text(t, style: AppText.style(size: 14, weight: FontWeight.w600, color: AppText.dim(0.65))),
        ),
      );
}

class _CityTile extends StatelessWidget {
  const _CityTile({
    required this.title,
    required this.subtitle,
    required this.onTap,
    this.trailing,
    this.leading,
  });

  final String title;
  final String subtitle;
  final VoidCallback onTap;
  final Widget? trailing;
  final Widget? leading;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: onTap,
        child: Glass(
          radius: 22,
          blur: 18,
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          child: Row(
            children: [
              if (leading != null) ...[leading!, const SizedBox(width: 12)],
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title, style: AppText.style(size: 16, weight: FontWeight.w800)),
                    if (subtitle.isNotEmpty)
                      Text(subtitle,
                          style: AppText.style(size: 12.5, weight: FontWeight.w600, color: AppText.dim(0.6))),
                  ],
                ),
              ),
              if (trailing != null) trailing!,
            ],
          ),
        ),
      ),
    );
  }
}
