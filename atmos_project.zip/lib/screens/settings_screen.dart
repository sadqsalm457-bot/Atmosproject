import 'package:flutter/material.dart';

import '../models/app_settings.dart';
import '../state/app_scope.dart';
import '../theme/app_text.dart';
import '../widgets/glass.dart';
import '../widgets/ui_icons.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  late final TextEditingController _key;

  @override
  void initState() {
    super.initState();
    _key = TextEditingController();
  }

  bool _init = false;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (!_init) {
      _init = true;
      _key.text = AppScope.of(context).settings.apiKey;
    }
  }

  @override
  void dispose() {
    _key.dispose();
    super.dispose();
  }

  Widget _section(String title, Widget child) => Padding(
        padding: const EdgeInsets.only(bottom: 14),
        child: Glass(
          radius: 26,
          blur: 22,
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(title, style: AppText.style(size: 13, weight: FontWeight.w700, color: AppText.dim(0.65))),
              const SizedBox(height: 10),
              child,
            ],
          ),
        ),
      );

  @override
  Widget build(BuildContext context) {
    final app = AppScope.of(context);
    final s = app.settings;
    final pad = MediaQuery.paddingOf(context);
    final hasKey = s.apiKey.trim().isNotEmpty;

    return Scaffold(
      backgroundColor: Colors.transparent,
      body: ListView(
        padding: EdgeInsets.fromLTRB(16, pad.top + 10, 16, pad.bottom + 28),
        children: [
          Row(
            children: [
              GlassButton(
                onTap: () => Navigator.of(context).pop(),
                child: const UiIcon(UiGlyph.back, size: 20),
              ),
              const SizedBox(width: 14),
              Text(app.tr('settings'), style: AppText.style(size: 24, weight: FontWeight.w800)),
            ],
          ),
          const SizedBox(height: 20),
          _section(
            app.tr('temp_unit'),
            Segmented<bool>(
              labels: const ['\u00B0C', '\u00B0F'],
              values: const [false, true],
              selected: s.fahrenheit,
              onChanged: (v) => app.updateSettings(s.copyWith(fahrenheit: v)),
            ),
          ),
          _section(
            app.tr('wind_unit'),
            Segmented<WindUnit>(
              labels: const ['km/h', 'm/s', 'mph'],
              values: WindUnit.values,
              selected: s.windUnit,
              onChanged: (v) => app.updateSettings(s.copyWith(windUnit: v)),
            ),
          ),
          _section(
            app.tr('language'),
            Segmented<String>(
              labels: const ['English', '\u0627\u0644\u0639\u0631\u0628\u064A\u0629'],
              values: const ['en', 'ar'],
              selected: s.lang,
              onChanged: (v) => app.updateSettings(s.copyWith(lang: v)),
            ),
          ),
          _section(
            app.tr('ai_key'),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 14),
                  decoration: BoxDecoration(
                    color: Colors.white.withValues(alpha: 0.08),
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: TextField(
                    controller: _key,
                    obscureText: true,
                    autocorrect: false,
                    enableSuggestions: false,
                    cursorColor: AppText.ink,
                    textDirection: TextDirection.ltr,
                    style: AppText.style(size: 14, weight: FontWeight.w600),
                    decoration: InputDecoration(
                      border: InputBorder.none,
                      hintText: app.tr('ai_key_hint'),
                      hintStyle: AppText.style(size: 13, weight: FontWeight.w500, color: AppText.dim(0.45)),
                      contentPadding: const EdgeInsets.symmetric(vertical: 14),
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    PillButton(
                      label: app.tr('save'),
                      filled: true,
                      onTap: () {
                        FocusScope.of(context).unfocus();
                        app.updateSettings(s.copyWith(apiKey: _key.text.trim()));
                      },
                    ),
                    const SizedBox(width: 10),
                    PillButton(
                      label: app.tr('clear'),
                      onTap: () {
                        _key.clear();
                        FocusScope.of(context).unfocus();
                        app.updateSettings(s.copyWith(apiKey: ''));
                      },
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                Text(
                  hasKey ? app.tr('ai_active') : app.tr('ai_local'),
                  style: AppText.style(
                    size: 13,
                    weight: FontWeight.w800,
                    color: hasKey ? const Color(0xFF5EE0A0) : AppText.dim(0.75),
                  ),
                ),
                const SizedBox(height: 4),
                Text(app.tr('ai_note'),
                    style: AppText.style(size: 12.5, weight: FontWeight.w500, color: AppText.dim(0.6), height: 1.4)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
