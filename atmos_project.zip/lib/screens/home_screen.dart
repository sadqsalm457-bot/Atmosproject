import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../models/weather_models.dart';
import '../state/app_scope.dart';
import '../state/app_state.dart';
import '../theme/app_text.dart';
import '../util/math_utils.dart';
import '../util/routes.dart';
import '../widgets/aqi_pill.dart';
import '../widgets/details_sheet.dart';
import '../widgets/error_view.dart';
import '../widgets/forecast_card.dart';
import '../widgets/glass.dart';
import '../widgets/hero_temp.dart';
import '../widgets/hourly_strip.dart';
import '../widgets/insights_card.dart';
import '../widgets/skeleton.dart';
import '../widgets/ui_icons.dart';
import 'search_screen.dart';
import 'settings_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final GlobalKey _cardKey = GlobalKey();
  final ScrollController _scroll = ScrollController();
  final DraggableScrollableController _sheet = DraggableScrollableController();
  int _token = 0;

  @override
  void initState() {
    super.initState();
    _scroll.addListener(_measure);
  }

  @override
  void dispose() {
    _scroll.dispose();
    _sheet.dispose();
    super.dispose();
  }

  void _measure() {
    if (!mounted) return;
    final engine = AppScope.engineOf(context);
    final ctx = _cardKey.currentContext;
    if (ctx == null) {
      engine.splashFrac = 1.3;
      return;
    }
    final box = ctx.findRenderObject();
    if (box is! RenderBox || !box.attached || !box.hasSize) return;
    final y = box.localToGlobal(Offset.zero).dy;
    final h = MediaQuery.sizeOf(context).height;
    engine.splashFrac = cl(y / h, 0.2, 1.3);
  }

  void _openDetails() {
    setState(() => _token++);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_sheet.isAttached) {
        _sheet.animateTo(0.93,
            duration: const Duration(milliseconds: 480), curve: Curves.easeOutCubic);
      }
    });
  }

  void _closeDetails() {
    if (_sheet.isAttached) {
      _sheet.animateTo(0,
          duration: const Duration(milliseconds: 320), curve: Curves.easeInCubic);
    }
  }

  @override
  Widget build(BuildContext context) {
    final app = AppScope.of(context);
    final b = app.bundle;
    WidgetsBinding.instance.addPostFrameCallback((_) => _measure());
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, result) {
        if (didPop) return;
        if (_sheet.isAttached && _sheet.size > 0.05) {
          _closeDetails();
        } else {
          SystemNavigator.pop();
        }
      },
      child: Scaffold(
        backgroundColor: Colors.transparent,
        body: Stack(
          children: [
            Positioned.fill(child: _content(app, b)),
            if (b != null)
              DraggableScrollableSheet(
                controller: _sheet,
                initialChildSize: 0.0,
                minChildSize: 0.0,
                maxChildSize: 0.94,
                snap: true,
                builder: (ctx, sc) => DetailsSheet(
                  key: ValueKey<int>(_token),
                  controller: sc,
                  onClose: _closeDetails,
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _content(AppState app, WeatherBundle? b) {
    if (b == null) {
      if (app.error != LoadError.none && !app.loading) {
        return ErrorView(kind: app.error, onRetry: app.refresh);
      }
      return const SkeletonView();
    }
    final pad = MediaQuery.paddingOf(context);
    final size = MediaQuery.sizeOf(context);
    final s = app.settings;
    final c = b.current;
    final today = b.today;
    final city = b.place.name.isEmpty ? app.tr('my_location') : b.place.name;
    final cond = app.tr(conditionKey(c.code, c.isDay));

    return RefreshIndicator(
      onRefresh: app.refresh,
      color: AppText.ink,
      backgroundColor: const Color(0xFF1B2140),
      edgeOffset: pad.top + 8,
      child: CustomScrollView(
        controller: _scroll,
        physics: const AlwaysScrollableScrollPhysics(),
        slivers: [
          SliverToBoxAdapter(
            child: Padding(
              padding: EdgeInsets.fromLTRB(22, pad.top + 10, 22, 0),
              child: Row(
                children: [
                  Expanded(
                    child: GestureDetector(
                      behavior: HitTestBehavior.opaque,
                      onTap: () => Navigator.of(context).push(fadeRoute<void>(const SearchScreen())),
                      child: Row(
                        children: [
                          const UiIcon(UiGlyph.pin, size: 18),
                          const SizedBox(width: 6),
                          Flexible(
                            child: Text(
                              city,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: AppText.style(size: 18, weight: FontWeight.w800),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  GlassButton(
                    onTap: () => Navigator.of(context).push(fadeRoute<void>(const SearchScreen())),
                    child: const UiIcon(UiGlyph.search, size: 20),
                  ),
                  const SizedBox(width: 10),
                  GlassButton(
                    onTap: () => Navigator.of(context).push(fadeRoute<void>(const SettingsScreen())),
                    child: const UiIcon(UiGlyph.settings, size: 20),
                  ),
                ],
              ),
            ),
          ),
          if (app.showingCache)
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(22, 12, 22, 0),
                child: Glass(
                  radius: 18,
                  blur: 14,
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
                  child: Text(app.tr('offline'),
                      style: AppText.style(size: 12.5, weight: FontWeight.w700, color: AppText.dim(0.85))),
                ),
              ),
            ),
          SliverToBoxAdapter(
            child: Padding(
              padding: EdgeInsets.fromLTRB(24, size.height * 0.04, 24, 0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  HeroTemp(value: s.temp(c.temp).round()),
                  const SizedBox(height: 4),
                  Text(
                    '$cond  \u00B7  ${app.tr('hi')} ${s.tempText(today.max)}  ${app.tr('lo')} ${s.tempText(today.min)}',
                    style: AppText.style(size: 16, weight: FontWeight.w700, color: AppText.dim(0.9)),
                  ),
                  if (b.air != null) ...[
                    const SizedBox(height: 14),
                    AqiPill(air: b.air!),
                  ],
                ],
              ),
            ),
          ),
          const SliverToBoxAdapter(child: SizedBox(height: 22)),
          const SliverToBoxAdapter(
            child: Padding(padding: EdgeInsets.symmetric(horizontal: 16), child: HourlyStrip()),
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
              child: KeyedSubtree(key: _cardKey, child: ForecastCard(onMore: _openDetails)),
            ),
          ),
          const SliverToBoxAdapter(
            child: Padding(padding: EdgeInsets.fromLTRB(16, 16, 16, 0), child: InsightsCard()),
          ),
          SliverToBoxAdapter(child: SizedBox(height: pad.bottom + 32)),
        ],
      ),
    );
  }
}
