import 'package:flutter/widgets.dart';

import '../weather_engine/engine_controller.dart';
import 'app_state.dart';

class AppScope extends InheritedNotifier<AppState> {
  const AppScope({
    super.key,
    required AppState app,
    required this.engine,
    required super.child,
  }) : super(notifier: app);

  final EngineController engine;

  static AppState of(BuildContext context) =>
      context.dependOnInheritedWidgetOfExactType<AppScope>()!.notifier!;

  static EngineController engineOf(BuildContext context) =>
      context.getInheritedWidgetOfExactType<AppScope>()!.engine;
}
