import 'dart:async';

import 'package:flutter/foundation.dart';

import '../l10n/strings.dart';
import '../models/app_settings.dart';
import '../models/insight.dart';
import '../models/weather_models.dart';
import '../services/ai_service.dart';
import '../services/insight_generator.dart';
import '../services/location_service.dart';
import '../services/storage.dart';
import '../services/weather_service.dart';

enum LoadError { none, serviceOff, denied, deniedForever, network }

class AppState extends ChangeNotifier {
  AppState(this.storage);

  final Storage storage;

  AppSettings settings = const AppSettings();
  List<CityPlace> saved = [];
  CityPlace? selected;
  WeatherBundle? bundle;
  bool loading = false;
  LoadError error = LoadError.none;
  Insight? insight;
  bool insightLoading = false;
  int _gen = 0;

  String get lang => settings.lang;
  bool get rtl => settings.lang == 'ar';
  String tr(String key) => Strings.t(settings.lang, key);
  bool get showingCache => bundle != null && error != LoadError.none;

  Future<void> init() async {
    settings = storage.loadSettings();
    saved = storage.loadCities();
    selected = storage.loadSelected();
    bundle = storage.loadBundle();
    if (bundle != null) {
      insight = InsightGenerator.local(bundle!, settings, tr);
    }
    notifyListeners();
    await refresh();
  }

  LoadError _map(LocationFailure f) {
    switch (f) {
      case LocationFailure.serviceOff:
        return LoadError.serviceOff;
      case LocationFailure.denied:
        return LoadError.denied;
      case LocationFailure.deniedForever:
        return LoadError.deniedForever;
      case LocationFailure.unknown:
        return LoadError.network;
    }
  }

  Future<void> refresh() async {
    final gen = ++_gen;
    loading = true;
    error = LoadError.none;
    notifyListeners();
    try {
      CityPlace place;
      final sel = selected;
      if (sel != null) {
        place = sel;
      } else {
        final r = await LocationService.locate();
        if (gen != _gen) return;
        final failure = r.failure;
        if (failure != null) {
          error = _map(failure);
          return;
        }
        place = CityPlace(name: '', country: '', lat: r.lat, lon: r.lon, gps: true);
      }
      final b = await WeatherService.fetch(place);
      if (gen != _gen) return;
      bundle = b;
      error = LoadError.none;
      await storage.saveBundle(b);
      unawaited(loadInsights());
    } catch (_) {
      if (gen == _gen) error = LoadError.network;
    } finally {
      if (gen == _gen) {
        loading = false;
        notifyListeners();
      }
    }
  }

  void maybeRefresh() {
    final b = bundle;
    if (b == null || DateTime.now().difference(b.fetchedAt).inMinutes > 20) {
      unawaited(refresh());
    }
  }

  Future<void> loadInsights() async {
    final b = bundle;
    if (b == null) return;
    insight = InsightGenerator.local(b, settings, tr);
    insightLoading = false;
    notifyListeners();
    final key = settings.apiKey.trim();
    if (key.isEmpty) return;
    insightLoading = true;
    notifyListeners();
    try {
      final ai = await AiService.generate(b, settings, key);
      if (identical(bundle, b)) insight = ai;
    } catch (_) {
      // keep the local suggestion
    }
    insightLoading = false;
    notifyListeners();
  }

  Future<void> selectPlace(CityPlace? p) async {
    selected = p;
    await storage.saveSelected(p);
    bundle = null;
    insight = null;
    notifyListeners();
    await refresh();
  }

  Future<void> addCity(CityPlace p) async {
    if (saved.any((c) => c.sameAs(p))) return;
    saved = [...saved, p];
    await storage.saveCities(saved);
    notifyListeners();
  }

  Future<void> removeCity(CityPlace p) async {
    saved = saved.where((c) => !c.sameAs(p)).toList();
    await storage.saveCities(saved);
    final sel = selected;
    if (sel != null && sel.sameAs(p)) {
      await selectPlace(null);
      return;
    }
    notifyListeners();
  }

  Future<void> updateSettings(AppSettings s) async {
    final langChanged = s.lang != settings.lang;
    final keyChanged = s.apiKey != settings.apiKey;
    settings = s;
    await storage.saveSettings(s);
    notifyListeners();
    final b = bundle;
    if (b == null) return;
    if (langChanged || keyChanged) {
      await loadInsights();
    } else if (insight?.fromAi != true) {
      insight = InsightGenerator.local(b, settings, tr);
      notifyListeners();
    }
  }
}
