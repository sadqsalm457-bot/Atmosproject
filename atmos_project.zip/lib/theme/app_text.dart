import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AppText {
  static const Color ink = Color(0xFFE6E9FF);

  static TextStyle style({
    double size = 14,
    FontWeight weight = FontWeight.w600,
    Color color = ink,
    double spacing = 0,
    double height = 1.25,
  }) {
    return GoogleFonts.plusJakartaSans(
      fontSize: size,
      fontWeight: weight,
      color: color,
      letterSpacing: spacing,
      height: height,
      fontFamilyFallback: const ['Roboto', 'sans-serif'],
    );
  }

  static Color dim(double a) => ink.withValues(alpha: a);
}
