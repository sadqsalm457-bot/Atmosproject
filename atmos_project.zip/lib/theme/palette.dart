import 'package:flutter/material.dart';

import '../util/math_utils.dart';

class SkyPalette {
  const SkyPalette(this.top, this.mid, this.bottom, this.cloudLight, this.cloudDark);

  final Color top;
  final Color mid;
  final Color bottom;
  final Color cloudLight;
  final Color cloudDark;

  static SkyPalette lerp(SkyPalette a, SkyPalette b, double t) => SkyPalette(
        Color.lerp(a.top, b.top, t)!,
        Color.lerp(a.mid, b.mid, t)!,
        Color.lerp(a.bottom, b.bottom, t)!,
        Color.lerp(a.cloudLight, b.cloudLight, t)!,
        Color.lerp(a.cloudDark, b.cloudDark, t)!,
      );

  static const clearDay = SkyPalette(Color(0xFF1F5FC7), Color(0xFF4A90E2), Color(0xFF8CC5F5), Color(0xFFFFFFFF), Color(0xFFB8CBE6));
  static const clearNight = SkyPalette(Color(0xFF070B24), Color(0xFF141A4A), Color(0xFF2A2F78), Color(0xFF5A63A0), Color(0xFF1D2250));
  static const overcastDay = SkyPalette(Color(0xFF5C6B82), Color(0xFF8593A8), Color(0xFFB4BFCD), Color(0xFFD5DCE8), Color(0xFF7D8BA3));
  static const overcastNight = SkyPalette(Color(0xFF141A2B), Color(0xFF222B42), Color(0xFF39435C), Color(0xFF4A5572), Color(0xFF171E33));
  static const rainDay = SkyPalette(Color(0xFF2E3B55), Color(0xFF47566F), Color(0xFF6C7B93), Color(0xFF8E9CB5), Color(0xFF3B4863));
  static const rainNight = SkyPalette(Color(0xFF10162A), Color(0xFF1B2440), Color(0xFF2C3658), Color(0xFF3A4566), Color(0xFF0F1426));
  static const snowDay = SkyPalette(Color(0xFF5F7399), Color(0xFF8497B8), Color(0xFFB5C3DA), Color(0xFFEAF0FA), Color(0xFF9AAAC6));
  static const snowNight = SkyPalette(Color(0xFF1B2540), Color(0xFF2C3A5C), Color(0xFF4A5C85), Color(0xFF6C7DA6), Color(0xFF2A3658));
  static const fogDay = SkyPalette(Color(0xFF6E7A8C), Color(0xFF8E99A9), Color(0xFFB0B9C6), Color(0xFFE3E7EE), Color(0xFFA4AEBC));
  static const fogNight = SkyPalette(Color(0xFF1E2433), Color(0xFF313A4B), Color(0xFF4A5568), Color(0xFF55607A), Color(0xFF262E42));
  static const stormDay = SkyPalette(Color(0xFF232A45), Color(0xFF343C5C), Color(0xFF4B5476), Color(0xFF6E7799), Color(0xFF2A3050));
  static const stormNight = SkyPalette(Color(0xFF0A0B1E), Color(0xFF1A1740), Color(0xFF2D2A66), Color(0xFF4C5488), Color(0xFF121631));
  static const golden = SkyPalette(Color(0xFF35397F), Color(0xFFD9764F), Color(0xFFFFC078), Color(0xFFFFD9B0), Color(0xFFB5686F));

  static SkyPalette _pair(SkyPalette day, SkyPalette night, double daylight) =>
      lerp(night, day, daylight);

  static SkyPalette build({
    required double cloud,
    required double rain,
    required double snow,
    required double fog,
    required double storm,
    required double daylight,
    required double golden,
  }) {
    var p = _pair(clearDay, clearNight, daylight);
    p = lerp(p, _pair(overcastDay, overcastNight, daylight), cl(cloud));
    p = lerp(p, _pair(rainDay, rainNight, daylight), cl(rain * 2));
    p = lerp(p, _pair(snowDay, snowNight, daylight), cl(snow * 2));
    p = lerp(p, _pair(fogDay, fogNight, daylight), cl(fog));
    p = lerp(p, _pair(stormDay, stormNight, daylight), cl(storm * 1.5));
    final g = cl(golden) * (1 - 0.75 * cl(cloud)) * (1 - cl(rain + snow + storm + fog));
    return lerp(p, SkyPalette.golden, cl(g));
  }
}
