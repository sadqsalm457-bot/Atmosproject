import 'dart:async';

import 'package:flutter/material.dart';

import 'screens/home_screen.dart';
import 'services/storage.dart';
import 'state/app_scope.dart';
import 'state/app_state.dart';
import 'weather_engine/engine_controller.dart';
import 'weather_engine/engine_state.dart';
import 'weather_engine/weather_scene.dart';

class AtmosApp extends StatefulWidget {
  const AtmosApp({super.key, required this.storage});

  final Storage storage;

  @override
  State<AtmosApp> createState() => _AtmosAppState();
}

class _AtmosAppState extends State<AtmosApp>
    with SingleTickerProviderStateMixin, WidgetsBindingObserver {
  late final AppState app;
  late final EngineController engine;
  late final ScenePainter painter;
  Timer? _timer;
  Object? _lastSynced;

  bool _reduce() =>
      WidgetsBinding.instance.platformDispatcher.accessibilityFeatures.disableAnimations;

  @override
  void initState() {
    super.initState();
    app = AppState(widget.storage);
    engine = EngineController(this);
    painter = ScenePainter(engine);
    engine.reduceMotion = _reduce();
    WidgetsBinding.instance.addObserver(this);
    app.addListener(_sync);
    engine.start();
    _timer = Timer.periodic(const Duration(minutes: 1), (_) => _sync(force: true));
    app.init();
  }

  void _sync({bool force = false}) {
    final b = app.bundle;
    if (b == null) return;
    if (!force && identical(b, _lastSynced)) return;
    final first = _lastSynced == null;
    _lastSynced = b;
    engine.setTarget(EngineState.fromBundle(b), instant: first);
  }

  @override
  void didChangeAccessibilityFeatures() {
    engine.reduceMotion = _reduce();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      engine.start();
      app.maybeRefresh();
    } else if (state == AppLifecycleState.paused || state == AppLifecycleState.hidden) {
      engine.pause();
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _timer?.cancel();
    app.removeListener(_sync);
    engine.dispose();
    app.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AppScope(
      app: app,
      engine: engine,
      child: MaterialApp(
        title: 'Atmos',
        debugShowCheckedModeBanner: false,
        locale: const Locale('en'),
        theme: ThemeData(
          useMaterial3: true,
          brightness: Brightness.dark,
          scaffoldBackgroundColor: Colors.transparent,
          canvasColor: Colors.transparent,
          splashFactory: NoSplash.splashFactory,
          highlightColor: Colors.transparent,
          textSelectionTheme: TextSelectionThemeData(
            cursorColor: const Color(0xFFE6E9FF),
            selectionColor: Colors.white.withValues(alpha: 0.25),
            selectionHandleColor: const Color(0xFFE6E9FF),
          ),
        ),
        builder: (context, child) {
          return AnimatedBuilder(
            animation: app,
            builder: (context, _) => Directionality(
              textDirection: app.rtl ? TextDirection.rtl : TextDirection.ltr,
              child: Stack(
                fit: StackFit.expand,
                children: [
                  WeatherScene(painter: painter),
                  if (child != null) child,
                ],
              ),
            ),
          );
        },
        home: const HomeScreen(),
      ),
    );
  }
}
