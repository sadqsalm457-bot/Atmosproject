import 'dart:math' as math;

import 'package:flutter/material.dart';

double cl(double v, [double lo = 0.0, double hi = 1.0]) =>
    v < lo ? lo : (v > hi ? hi : v);

double lerpD(double a, double b, double t) => a + (b - a) * t;

double smooth(double e0, double e1, double x) {
  final t = cl((x - e0) / (e1 - e0));
  return t * t * (3 - 2 * t);
}

double frac(double v) => v - v.floorToDouble();

double hash01(int n) {
  final x = math.sin(n * 12.9898 + 4.1414) * 43758.5453;
  return x - x.floorToDouble();
}

void drawText(Canvas c, String text, Offset center, TextStyle style) {
  final tp = TextPainter(
    text: TextSpan(text: text, style: style),
    textDirection: TextDirection.ltr,
  )..layout();
  tp.paint(c, center - Offset(tp.width / 2, tp.height / 2));
}

Path dashed(Path src, double on, double off) {
  final out = Path();
  for (final m in src.computeMetrics()) {
    double d = 0;
    while (d < m.length) {
      final e = math.min(d + on, m.length);
      out.addPath(m.extractPath(d, e), Offset.zero);
      d += on + off;
    }
  }
  return out;
}

/// Colour for a temperature in Celsius: blue -> green -> amber.
Color tempColor(double c) {
  const blue = Color(0xFF4C8DFF);
  const green = Color(0xFF4FD99B);
  const amber = Color(0xFFFFB347);
  if (c <= 4) return blue;
  if (c <= 18) return Color.lerp(blue, green, (c - 4) / 14)!;
  if (c <= 32) return Color.lerp(green, amber, (c - 18) / 14)!;
  return amber;
}
