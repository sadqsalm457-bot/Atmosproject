import 'dart:math' as math;

import '../models/weather_models.dart';
import '../theme/palette.dart';
import '../util/math_utils.dart';

class EngineState {
  const EngineState({
    required this.cloud,
    required this.rain,
    required this.snow,
    required this.fog,
    required this.storm,
    required this.wind,
    required this.windDx,
    required this.daylight,
    required this.golden,
    required this.celest,
    required this.palette,
  });

  final double cloud;
  final double rain;
  final double snow;
  final double fog;
  final double storm;
  final double wind;
  final double windDx;
  final double daylight;
  final double golden;
  final double celest;
  final SkyPalette palette;

  static final EngineState initial = EngineState(
    cloud: 0.2,
    rain: 0,
    snow: 0,
    fog: 0,
    storm: 0,
    wind: 0.15,
    windDx: 1,
    daylight: 0,
    golden: 0,
    celest: 0.4,
    palette: SkyPalette.build(
      cloud: 0.2,
      rain: 0,
      snow: 0,
      fog: 0,
      storm: 0,
      daylight: 0,
      golden: 0,
    ),
  );

  static EngineState lerp(EngineState a, EngineState b, double t) {
    double l(double x, double y) => x + (y - x) * t;
    return EngineState(
      cloud: l(a.cloud, b.cloud),
      rain: l(a.rain, b.rain),
      snow: l(a.snow, b.snow),
      fog: l(a.fog, b.fog),
      storm: l(a.storm, b.storm),
      wind: l(a.wind, b.wind),
      windDx: l(a.windDx, b.windDx),
      daylight: l(a.daylight, b.daylight),
      golden: l(a.golden, b.golden),
      celest: l(a.celest, b.celest),
      palette: SkyPalette.lerp(a.palette, b.palette, t),
    );
  }

  static double _rainBase(int code) {
    switch (code) {
      case 51:
        return 0.12;
      case 53:
        return 0.2;
      case 55:
        return 0.3;
      case 56:
        return 0.2;
      case 57:
        return 0.3;
      case 61:
        return 0.3;
      case 63:
        return 0.55;
      case 65:
        return 0.85;
      case 66:
        return 0.35;
      case 67:
        return 0.7;
      case 80:
        return 0.4;
      case 81:
        return 0.65;
      case 82:
        return 0.95;
      case 95:
        return 0.7;
      case 96:
        return 0.8;
      case 99:
        return 0.9;
      default:
        return 0.0;
    }
  }

  static double _snowBase(int code) {
    switch (code) {
      case 71:
        return 0.3;
      case 73:
        return 0.6;
      case 75:
        return 0.9;
      case 77:
        return 0.25;
      case 85:
        return 0.5;
      case 86:
        return 0.85;
      default:
        return 0.4;
    }
  }

  factory EngineState.fromBundle(WeatherBundle b) {
    final c = b.current;
    final now = b.localNow;
    final today = b.today;
    final k = kindOf(c.code);

    var cloud = c.cloud / 100.0;
    var rain = 0.0;
    var snow = 0.0;
    var storm = 0.0;
    var fog = 0.0;

    final isSnow = k == Kind.snow;
    final isRain = k == Kind.drizzle ||
        k == Kind.rain ||
        k == Kind.showers ||
        k == Kind.freezing ||
        k == Kind.thunder;

    if (isSnow) {
      snow = math.max(_snowBase(c.code), cl(c.precip / 3));
    } else if (isRain) {
      rain = math.max(_rainBase(c.code), cl(c.precip / 6));
    } else if (c.precip > 0.3) {
      rain = cl(c.precip / 6);
    }
    if (k == Kind.thunder) storm = c.code == 95 ? 0.8 : 1.0;

    if (k == Kind.overcast) cloud = math.max(cloud, 0.85);
    if (isRain || rain > 0) cloud = math.max(cloud, rain > 0.5 ? 0.9 : 0.75);
    if (isSnow) cloud = math.max(cloud, 0.75);
    if (k == Kind.thunder) cloud = math.max(cloud, 0.92);
    if (k == Kind.fog) cloud = math.max(cloud, 0.45);

    if (k == Kind.fog) {
      fog = 0.85;
    } else if (c.visibility > 0 && c.visibility < 3000 && rain == 0 && snow == 0) {
      fog = cl((1 - c.visibility / 3000) * 0.7);
    }

    final wind = cl(c.windKmh / 60);
    final windDx = math.sin((c.windDir + 180) * math.pi / 180);

    final msr = now.difference(today.sunrise).inMinutes.toDouble();
    final mts = today.sunset.difference(now).inMinutes.toDouble();
    final daylight = smooth(-30, 30, msr) * smooth(-30, 30, mts);
    final golden = math.max(
      math.exp(-math.pow(msr / 50, 2).toDouble()),
      math.exp(-math.pow(mts / 50, 2).toDouble()),
    );

    double celest;
    if (now.isAfter(today.sunrise) && now.isBefore(today.sunset)) {
      celest = cl(now.difference(today.sunrise).inSeconds /
          today.sunset.difference(today.sunrise).inSeconds);
    } else {
      DateTime prevSet;
      DateTime nextRise;
      if (now.isBefore(today.sunrise)) {
        prevSet = today.sunset.subtract(const Duration(days: 1));
        nextRise = today.sunrise;
      } else {
        prevSet = today.sunset;
        nextRise = today.sunrise.add(const Duration(days: 1));
      }
      celest = cl(now.difference(prevSet).inSeconds / nextRise.difference(prevSet).inSeconds);
    }

    return EngineState(
      cloud: cl(cloud),
      rain: rain,
      snow: snow,
      fog: fog,
      storm: storm,
      wind: wind,
      windDx: windDx,
      daylight: daylight,
      golden: golden,
      celest: celest,
      palette: SkyPalette.build(
        cloud: cl(cloud),
        rain: rain,
        snow: snow,
        fog: fog,
        storm: storm,
        daylight: daylight,
        golden: golden,
      ),
    );
  }
}
