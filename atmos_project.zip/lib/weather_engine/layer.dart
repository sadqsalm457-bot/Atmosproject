import 'package:flutter/material.dart';

import 'engine_controller.dart';

abstract class SceneLayer {
  void paint(Canvas canvas, Size size, EngineController e);
}
