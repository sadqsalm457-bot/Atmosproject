import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../util/math_utils.dart';
import 'engine_controller.dart';
import 'layer.dart';

class SnowPainter implements SceneLayer {
  SnowPainter() {
    final r = math.Random(33);
    for (var i = 0; i < _max; i++) {
      _x0[i] = r.nextDouble();
      _y0[i] = r.nextDouble();
      _ph[i] = r.nextDouble() * 6.28;
      _fj[i] = 0.7 + r.nextDouble() * 0.8;
    }
  }

  static const int _max = 420;
  static const List<double> _size = [1.3, 2.1, 3.3];
  static const List<double> _speed = [0.06, 0.09, 0.13];
  static const List<double> _alpha = [0.45, 0.65, 0.92];

  final List<double> _x0 = List<double>.filled(_max, 0);
  final List<double> _y0 = List<double>.filled(_max, 0);
  final List<double> _ph = List<double>.filled(_max, 0);
  final List<double> _fj = List<double>.filled(_max, 0);
  final List<Paint> _paints = [
    Paint()..maskFilter = const MaskFilter.blur(BlurStyle.normal, 1.4),
    Paint(),
    Paint()..maskFilter = const MaskFilter.blur(BlurStyle.normal, 0.8),
  ];

  @override
  void paint(Canvas canvas, Size size, EngineController e) {
    final st = e.current;
    if (st.snow < 0.02) return;
    final w = size.width;
    final h = size.height;
    final n = math.min(_max, ((80 + 340 * st.snow) * (e.reduceMotion ? 0.5 : 1.0)).round());
    final fade = cl(st.snow * 4);
    final t = e.time;
    final drift = st.windDx * st.wind;
    for (var l = 0; l < 3; l++) {
      _paints[l].color = Colors.white.withValues(alpha: _alpha[l] * fade);
    }
    for (var i = 0; i < n; i++) {
      final layer = i % 3;
      final v = _speed[layer] * h;
      final period = (h + 40) / v;
      final y = -20 + frac(_y0[i] + t / period) * (h + 40);
      final x = (_x0[i] * w +
              math.sin(t * 0.8 * _fj[i] + _ph[i]) * (10 + 14 * layer) +
              math.sin(t * 0.31 + _ph[i] * 2) * 18 +
              drift * y * 0.25 +
              t * drift * 20) %
          w;
      canvas.drawCircle(Offset(x, y), _size[layer], _paints[layer]);
    }
  }
}
