import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../util/math_utils.dart';
import 'engine_controller.dart';
import 'layer.dart';

class WindPainter implements SceneLayer {
  final Paint _p = Paint()
    ..style = PaintingStyle.stroke
    ..strokeWidth = 1.2
    ..strokeCap = StrokeCap.round;

  @override
  void paint(Canvas canvas, Size size, EngineController e) {
    final w = e.current.wind;
    if (w < 0.4) return;
    final a = (w - 0.4) * 0.5;
    _p.color = Colors.white.withValues(alpha: a);
    for (var i = 0; i < 14; i++) {
      final len = 90 + hash01(i + 7) * 120;
      final span = size.width + len * 2;
      final sx = hash01(i + 3) * span;
      final sy = size.height * (0.08 + 0.8 * hash01(i + 19));
      final speed = 0.8 + hash01(i + 29);
      final x = ((sx + e.windScroll * speed) % span) - len;
      final wob = 6 * math.sin(e.time * 1.3 + i);
      final path = Path()
        ..moveTo(x, sy)
        ..quadraticBezierTo(x + len * 0.5, sy - wob, x + len, sy);
      canvas.drawPath(path, _p);
    }
  }
}
