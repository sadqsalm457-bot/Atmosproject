import 'package:flutter/material.dart';

import 'engine_controller.dart';
import 'layer.dart';

class LightningPainter implements SceneLayer {
  final Paint _p = Paint();
  final Paint _glow = Paint()
    ..style = PaintingStyle.stroke
    ..strokeWidth = 6
    ..strokeJoin = StrokeJoin.round
    ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 6);
  final Paint _core = Paint()
    ..style = PaintingStyle.stroke
    ..strokeWidth = 1.8
    ..strokeJoin = StrokeJoin.round;

  @override
  void paint(Canvas canvas, Size size, EngineController e) {
    final f = e.flash;
    if (f <= 0.01 || e.current.storm < 0.1) return;
    final k = e.reduceMotion ? 0.3 : 1.0;
    final rect = Offset.zero & size;

    _p.blendMode = BlendMode.screen;
    _p.shader = null;
    _p.color = const Color(0xFFC9D2FF).withValues(alpha: 0.22 * f * k);
    canvas.drawRect(rect, _p);

    final o = Offset(size.width * e.flashOrigin.dx, size.height * (e.flashOrigin.dy + 0.08));
    _p.shader = RadialGradient(
      colors: [
        const Color(0xFFE8ECFF).withValues(alpha: 0.75 * f * k),
        const Color(0xFFB9C4FF).withValues(alpha: 0.25 * f * k),
        const Color(0x00B9C4FF),
      ],
      stops: const [0.0, 0.4, 1.0],
    ).createShader(Rect.fromCircle(center: o, radius: size.width * 0.8));
    canvas.drawRect(rect, _p);
    _p.shader = null;
    _p.blendMode = BlendMode.srcOver;

    if (!e.reduceMotion && f > 0.4 && e.bolt.length > 1) {
      final path = Path()
        ..moveTo(e.bolt.first.dx * size.width, e.bolt.first.dy * size.height);
      for (final pt in e.bolt.skip(1)) {
        path.lineTo(pt.dx * size.width, pt.dy * size.height);
      }
      _glow.color = const Color(0xFFB9C4FF).withValues(alpha: f * 0.8);
      _core.color = Colors.white.withValues(alpha: f);
      canvas.drawPath(path, _glow);
      canvas.drawPath(path, _core);
    }
  }
}
