import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../util/math_utils.dart';
import 'engine_controller.dart';
import 'layer.dart';

class StarPainter implements SceneLayer {
  StarPainter() {
    final r = math.Random(11);
    for (var i = 0; i < 150; i++) {
      _x.add(r.nextDouble());
      _y.add(r.nextDouble() * 0.6);
      _size.add(0.6 + r.nextDouble() * 1.0);
      _phase.add(r.nextDouble() * 6.28);
      _speed.add(0.6 + r.nextDouble() * 1.8);
    }
  }

  final List<double> _x = [];
  final List<double> _y = [];
  final List<double> _size = [];
  final List<double> _phase = [];
  final List<double> _speed = [];
  final Paint _p = Paint();

  @override
  void paint(Canvas canvas, Size size, EngineController e) {
    final st = e.current;
    final vis = cl((1 - st.daylight) * (1 - st.cloud * 0.92) * (1 - st.fog) * (1 - st.snow));
    if (vis < 0.02) return;
    final t = e.time;
    for (var i = 0; i < _x.length; i++) {
      final tw = 0.5 + 0.5 * math.sin(t * _speed[i] + _phase[i]);
      final a = vis * (0.35 + 0.65 * tw);
      final c = Offset(_x[i] * size.width, _y[i] * size.height);
      _p.color = Colors.white.withValues(alpha: a);
      canvas.drawCircle(c, _size[i], _p);
      if (_size[i] > 1.35) {
        _p.color = Colors.white.withValues(alpha: a * 0.18);
        canvas.drawCircle(c, _size[i] * 2.6, _p);
      }
    }

    if (vis > 0.5 && !e.reduceMotion) {
      const cycle = 9.0;
      final ci = (t / cycle).floor();
      final local = t - ci * cycle;
      const dur = 0.9;
      if (local < dur) {
        final u = local / dur;
        final r1 = hash01(ci);
        final r2 = hash01(ci + 101);
        final start = Offset(size.width * (0.3 + 0.6 * r1), size.height * (0.04 + 0.18 * r2));
        const dir = Offset(-0.9, 0.43);
        final head = start + dir * (u * size.width * 0.45);
        final tail = head - dir * 80;
        final a = vis * math.sin(math.pi * u);
        final line = Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1.6
          ..strokeCap = StrokeCap.round
          ..shader = LinearGradient(colors: [
            Colors.white.withValues(alpha: a),
            Colors.white.withValues(alpha: 0),
          ]).createShader(Rect.fromPoints(tail, head));
        canvas.drawLine(tail, head, line);
      }
    }
  }
}
