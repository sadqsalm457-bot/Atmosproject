import 'package:flutter/material.dart';

import 'engine_controller.dart';
import 'layer.dart';

class SkyPainter implements SceneLayer {
  final Paint _p = Paint();

  @override
  void paint(Canvas canvas, Size size, EngineController e) {
    final pal = e.current.palette;
    final rect = Offset.zero & size;
    _p.shader = LinearGradient(
      begin: Alignment.topCenter,
      end: Alignment.bottomCenter,
      colors: [pal.top, pal.mid, pal.bottom],
      stops: const [0.0, 0.55, 1.0],
    ).createShader(rect);
    canvas.drawRect(rect, _p);

    _p.shader = const LinearGradient(
      begin: Alignment.topCenter,
      end: Alignment.bottomCenter,
      colors: [Color(0x00000000), Color(0x47000000)],
      stops: [0.5, 1.0],
    ).createShader(rect);
    canvas.drawRect(rect, _p);
    _p.shader = null;
  }
}
