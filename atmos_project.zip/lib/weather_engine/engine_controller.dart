import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter/services.dart';

import 'engine_state.dart';

/// Owns the single Ticker that drives the whole weather scene.
class EngineController extends ChangeNotifier {
  EngineController(TickerProvider vsync) {
    _ticker = vsync.createTicker(_onTick);
  }

  late final Ticker _ticker;

  EngineState current = EngineState.initial;
  EngineState _from = EngineState.initial;
  EngineState _to = EngineState.initial;
  double _blend = 1;

  bool reduceMotion = false;
  double time = 0; // scaled by reduce-motion
  double rawTime = 0; // real seconds, used by small icons
  final List<double> cloudScroll = [0, 0, 0, 0];
  double windScroll = 0;
  double splashFrac = 0.62;

  double flash = 0;
  Offset flashOrigin = const Offset(0.5, 0.1);
  List<Offset> bolt = const [];
  double _sinceFlash = 99;
  double _nextFlash = 2.5;
  final math.Random _rng = math.Random(7);
  Duration _last = Duration.zero;

  bool get running => _ticker.isActive;

  void setTarget(EngineState s, {bool instant = false}) {
    if (instant) {
      current = s;
      _from = s;
      _to = s;
      _blend = 1;
    } else {
      _from = current;
      _to = s;
      _blend = 0;
    }
    notifyListeners();
  }

  void start() {
    if (_ticker.isActive) return;
    _last = Duration.zero;
    _ticker.start();
  }

  void pause() {
    if (_ticker.isActive) _ticker.stop();
  }

  double _flashCurve(double t) {
    if (t < 0.07) return t / 0.07;
    if (t < 0.14) return 1.0;
    if (t < 0.22) return 0.25;
    if (t < 0.30) return 0.25 + 0.7 * ((t - 0.22) / 0.08);
    if (t < 0.9) {
      final k = 1 - (t - 0.30) / 0.6;
      return 0.95 * k * k;
    }
    return 0.0;
  }

  void _triggerFlash(double storm) {
    _sinceFlash = 0;
    _nextFlash = (3 + _rng.nextDouble() * 6) / (0.5 + storm * 0.8);
    flashOrigin = Offset(0.15 + _rng.nextDouble() * 0.7, 0.04 + _rng.nextDouble() * 0.08);
    final pts = <Offset>[];
    var x = flashOrigin.dx;
    var y = 0.0;
    pts.add(Offset(x, y));
    while (y < 0.4) {
      y += 0.03 + _rng.nextDouble() * 0.04;
      x += (_rng.nextDouble() - 0.5) * 0.07;
      pts.add(Offset(x, y));
    }
    bolt = pts;
    if (!reduceMotion) {
      HapticFeedback.heavyImpact();
      Future<void>.delayed(const Duration(milliseconds: 220), HapticFeedback.lightImpact);
    }
  }

  void _onTick(Duration elapsed) {
    var dt = (elapsed - _last).inMicroseconds / 1e6;
    _last = elapsed;
    if (dt > 0.05) dt = 0.05;
    if (dt < 0) dt = 0;

    rawTime += dt;
    final sd = dt * (reduceMotion ? 0.35 : 1.0);
    time += sd;

    if (_blend < 1) {
      _blend = math.min(1.0, _blend + dt / 1.0);
      current = _blend >= 1
          ? _to
          : EngineState.lerp(_from, _to, Curves.easeInOutCubic.transform(_blend));
    }

    final s = current;
    final windMul = 0.4 + s.wind * 2.4;
    final dx = s.windDx.abs() < 0.25 ? (s.windDx < 0 ? -0.25 : 0.25) : s.windDx;
    for (var i = 0; i < 4; i++) {
      cloudScroll[i] += sd * (5 + 9 * i) * windMul * dx;
    }
    windScroll += sd * (80 + 300 * s.wind) * dx;

    _sinceFlash += dt;
    if (s.storm > 0.2) {
      _nextFlash -= dt;
      if (_nextFlash <= 0) _triggerFlash(s.storm);
    }
    flash = _sinceFlash < 1.0 ? _flashCurve(_sinceFlash) : 0.0;

    notifyListeners();
  }

  @override
  void dispose() {
    _ticker.dispose();
    super.dispose();
  }
}
