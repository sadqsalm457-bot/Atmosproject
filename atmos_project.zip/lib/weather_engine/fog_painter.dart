import 'package:flutter/material.dart';

import '../util/math_utils.dart';
import 'engine_controller.dart';
import 'layer.dart';

class FogPainter implements SceneLayer {
  final Paint _p = Paint();

  @override
  void paint(Canvas canvas, Size size, EngineController e) {
    final f = e.current.fog;
    if (f < 0.02) return;
    final pal = e.current.palette;
    final w = size.width;
    final h = size.height;
    final rect = Offset.zero & size;

    _p.shader = LinearGradient(
      begin: Alignment.topCenter,
      end: Alignment.bottomCenter,
      colors: [
        pal.cloudLight.withValues(alpha: f * 0.22),
        pal.cloudLight.withValues(alpha: f * 0.42),
      ],
    ).createShader(rect);
    canvas.drawRect(rect, _p);

    for (var i = 0; i < 6; i++) {
      final bw = w * (0.9 + 0.2 * (i % 3));
      final bh = h * 0.09;
      final span = w + bw * 2;
      final seed = hash01(i + 40);
      final x = ((seed * span + e.cloudScroll[i % 4] * 1.6) % span) - bw;
      final y = h * (0.22 + 0.11 * i);
      _p.shader = RadialGradient(
        colors: [
          pal.cloudLight.withValues(alpha: f * 0.30),
          pal.cloudLight.withValues(alpha: 0),
        ],
      ).createShader(const Rect.fromLTWH(-1, -1, 2, 2));
      canvas.save();
      canvas.translate(x + bw / 2, y);
      canvas.scale(bw / 2, bh);
      canvas.drawCircle(Offset.zero, 1.0, _p);
      canvas.restore();
    }
    _p.shader = null;
  }
}
