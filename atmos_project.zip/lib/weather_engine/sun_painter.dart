import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../util/math_utils.dart';
import 'engine_controller.dart';
import 'layer.dart';

class SunPainter implements SceneLayer {
  final Paint _p = Paint();
  final Paint _ray = Paint()
    ..style = PaintingStyle.stroke
    ..strokeCap = StrokeCap.round;

  @override
  void paint(Canvas canvas, Size size, EngineController e) {
    final st = e.current;
    final w = size.width;
    final h = size.height;
    final pos = Offset(w * (0.25 + 0.6 * st.celest), h * (0.36 - 0.24 * math.sin(math.pi * st.celest)));

    final day = st.daylight;
    final clear = 1 - st.cloud;
    final glowA = day * (0.25 + 0.75 * clear) * (1 - st.rain * 0.7) * (1 - st.fog * 0.5);
    final discA = day * clear * clear * (1 - st.rain) * (1 - st.fog) * (1 - st.snow);
    final col = Color.lerp(const Color(0xFFFFF4D6), const Color(0xFFFFB066), st.golden)!;

    if (glowA > 0.02) {
      final r = w * 0.55;
      _p.shader = RadialGradient(
        colors: [
          col.withValues(alpha: glowA * 0.55),
          col.withValues(alpha: glowA * 0.18),
          col.withValues(alpha: 0),
        ],
        stops: const [0.0, 0.35, 1.0],
      ).createShader(Rect.fromCircle(center: pos, radius: r));
      canvas.drawCircle(pos, r, _p);
      _p.shader = null;
    }

    if (discA > 0.02) {
      final ang0 = e.time * 0.06;
      for (var i = 0; i < 14; i++) {
        final a = ang0 + i * math.pi * 2 / 14;
        final len = 60 + 50 * (0.5 + 0.5 * math.sin(e.time * 0.7 + i * 1.7));
        final d = Offset(math.cos(a), math.sin(a));
        _ray
          ..strokeWidth = 3
          ..color = col.withValues(alpha: discA * 0.22);
        canvas.drawLine(pos + d * 46, pos + d * (46 + len), _ray);
      }
      _p.shader = RadialGradient(
        center: const Alignment(-0.3, -0.3),
        colors: [Colors.white.withValues(alpha: discA), col.withValues(alpha: discA)],
      ).createShader(Rect.fromCircle(center: pos, radius: 34));
      canvas.drawCircle(pos, 34, _p);
      _p.shader = null;
    }

    final nightA = (1 - day) * (1 - st.cloud * 0.85) * (1 - st.fog) * (1 - st.rain) * (1 - st.snow);
    if (nightA > 0.02) {
      const r = 26.0;
      _p.shader = RadialGradient(
        colors: [
          const Color(0xFFC9D2FF).withValues(alpha: nightA * 0.35),
          const Color(0xFFC9D2FF).withValues(alpha: 0),
        ],
      ).createShader(Rect.fromCircle(center: pos, radius: r * 3));
      canvas.drawCircle(pos, r * 3, _p);
      _p.shader = null;
      final moon = Path.combine(
        PathOperation.difference,
        Path()..addOval(Rect.fromCircle(center: pos, radius: r)),
        Path()..addOval(Rect.fromCircle(center: pos.translate(r * 0.55, -r * 0.25), radius: r * 0.92)),
      );
      _p.color = const Color(0xFFF1F3FF).withValues(alpha: nightA);
      canvas.drawPath(moon, _p);
    }
  }
}
