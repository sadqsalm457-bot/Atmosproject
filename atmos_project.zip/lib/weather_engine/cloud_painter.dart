import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../util/math_utils.dart';
import 'engine_controller.dart';
import 'layer.dart';

class _Puff {
  const _Puff(this.dx, this.dy, this.r);
  final double dx;
  final double dy;
  final double r;
}

class _Cloud {
  const _Cloud(this.x, this.y, this.scale, this.thr, this.puffs);
  final double x;
  final double y;
  final double scale;
  final double thr;
  final List<_Puff> puffs;
}

class CloudPainter implements SceneLayer {
  CloudPainter() {
    final rnd = math.Random(5);
    for (var l = 0; l < 4; l++) {
      final list = <_Cloud>[];
      for (var i = 0; i < 6; i++) {
        final puffs = <_Puff>[];
        final np = 5 + rnd.nextInt(3);
        for (var k = 0; k < np; k++) {
          final t = k / (np - 1);
          final bump = math.sin(t * math.pi);
          puffs.add(_Puff(
            (t - 0.5) * 0.9,
            (rnd.nextDouble() - 0.6) * 0.10 - bump * 0.06,
            0.16 + rnd.nextDouble() * 0.12 + bump * 0.08,
          ));
        }
        list.add(_Cloud(
          rnd.nextDouble(),
          0.04 + rnd.nextDouble() * 0.28,
          0.8 + rnd.nextDouble() * 0.5,
          (i + 0.5) / 6 * 0.9,
          puffs,
        ));
      }
      _layers.add(list);
    }
  }

  final List<List<_Cloud>> _layers = [];
  final Paint _p = Paint();

  @override
  void paint(Canvas canvas, Size size, EngineController e) {
    final st = e.current;
    final cover = st.cloud;
    if (cover < 0.03) return;
    final pal = st.palette;
    final dark = cl(0.15 * cover + 0.75 * math.max(st.rain, st.storm));
    final w = size.width;
    final h = size.height;

    for (var l = 0; l < 4; l++) {
      final depth = l / 3.0;
      var col = Color.lerp(pal.cloudLight, pal.cloudDark, dark)!;
      col = Color.lerp(col, pal.mid, (1 - depth) * 0.35)!;
      col = Color.lerp(col, const Color(0xFFDDE4FF), cl(e.flash * 0.85))!;
      final baseA = (0.35 + 0.17 * l) * (0.55 + 0.45 * cover);
      final mid = 0.30 + 0.1 * l;
      final cw = w * (0.55 + 0.17 * l);
      final span = w + cw * 3.2;
      final scroll = e.cloudScroll[l];

      for (final cloud in _layers[l]) {
        final a = cl((cover - cloud.thr) / 0.25) * baseA;
        if (a < 0.02) continue;
        final cwi = cw * cloud.scale;
        final cx = ((cloud.x * span + scroll) % span) - cw * 1.6;
        final cy = h * (cloud.y + 0.02 * l);

        _p.shader = RadialGradient(
          colors: [
            col.withValues(alpha: a),
            col.withValues(alpha: a * 0.55),
            col.withValues(alpha: 0),
          ],
          stops: [0.0, mid, 1.0],
        ).createShader(const Rect.fromLTWH(-1, -1, 2, 2));

        for (final pf in cloud.puffs) {
          final r = pf.r * cwi;
          canvas.save();
          canvas.translate(cx + pf.dx * cwi, cy + pf.dy * cwi);
          canvas.scale(r * 1.5, r);
          canvas.drawCircle(Offset.zero, 1.0, _p);
          canvas.restore();
        }
      }
    }
    _p.shader = null;
  }
}
