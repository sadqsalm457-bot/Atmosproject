import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../models/weather_models.dart';
import '../state/app_scope.dart';
import '../util/math_utils.dart';
import '../weather_engine/engine_controller.dart';

class WeatherIcon extends StatelessWidget {
  const WeatherIcon({super.key, required this.code, required this.isDay, this.size = 32});

  final int code;
  final bool isDay;
  final double size;

  @override
  Widget build(BuildContext context) {
    final engine = AppScope.engineOf(context);
    return RepaintBoundary(
      child: CustomPaint(
        size: Size.square(size),
        painter: WeatherIconPainter(code, isDay, engine),
      ),
    );
  }
}

class WeatherIconPainter extends CustomPainter {
  WeatherIconPainter(this.code, this.isDay, this.engine) : super(repaint: engine);

  final int code;
  final bool isDay;
  final EngineController engine;

  static final Paint _p = Paint()..isAntiAlias = true;

  Paint _f(Color c) => _p
    ..shader = null
    ..maskFilter = null
    ..style = PaintingStyle.fill
    ..color = c;

  Paint _s(Color c, double w) => _p
    ..shader = null
    ..maskFilter = null
    ..style = PaintingStyle.stroke
    ..strokeWidth = w
    ..strokeCap = StrokeCap.round
    ..strokeJoin = StrokeJoin.round
    ..color = c;

  @override
  void paint(Canvas c, Size size) {
    final u = size.width;
    final t = engine.rawTime;
    final k = kindOf(code);
    final bob = math.sin(t * 1.1) * 0.012 * u;

    switch (k) {
      case Kind.clear:
        if (isDay) {
          _sun(c, u, Offset(u * .5, u * .5), u * .2, t);
        } else {
          _moon(c, u, Offset(u * .5, u * .5), u * .27);
        }
      case Kind.mainlyClear:
      case Kind.partly:
        if (isDay) {
          _sun(c, u, Offset(u * .38, u * .38), u * .15, t);
        } else {
          _moon(c, u, Offset(u * .36, u * .38), u * .19);
        }
        _cloud(c, Rect.fromLTWH(u * .2, u * .38 + bob, u * .7, u * .46), dark: false);
      case Kind.overcast:
        _cloud(c, Rect.fromLTWH(u * .3, u * .14, u * .6, u * .4), dark: true);
        _cloud(c, Rect.fromLTWH(u * .08, u * .34 + bob, u * .74, u * .5), dark: false);
      case Kind.fog:
        _cloud(c, Rect.fromLTWH(u * .14, u * .1 + bob, u * .72, u * .46), dark: false);
        for (var i = 0; i < 3; i++) {
          final off = math.sin(t * .8 + i) * u * .04;
          final y = u * (.68 + i * .11);
          c.drawLine(Offset(u * .22 + off, y), Offset(u * .78 + off, y),
              _s(Colors.white.withValues(alpha: .7), u * .045));
        }
      case Kind.drizzle:
        final r = Rect.fromLTWH(u * .12, u * .14 + bob, u * .76, u * .5);
        _cloud(c, r, dark: true);
        _drops(c, u, r, t, 3, const Color(0xFF9CCBFF), .06);
      case Kind.rain:
        final r = Rect.fromLTWH(u * .12, u * .14 + bob, u * .76, u * .5);
        _cloud(c, r, dark: true);
        _drops(c, u, r, t, 4, const Color(0xFF6FB6FF), .09);
      case Kind.showers:
        if (isDay) {
          _sun(c, u, Offset(u * .34, u * .3), u * .13, t);
        } else {
          _moon(c, u, Offset(u * .32, u * .3), u * .16);
        }
        final r = Rect.fromLTWH(u * .16, u * .26 + bob, u * .72, u * .44);
        _cloud(c, r, dark: true);
        _drops(c, u, r, t, 3, const Color(0xFF6FB6FF), .08);
      case Kind.freezing:
        final r = Rect.fromLTWH(u * .12, u * .14 + bob, u * .76, u * .5);
        _cloud(c, r, dark: true);
        _drops(c, u, r, t, 3, const Color(0xFFBFE6FF), .08);
      case Kind.snow:
        final r = Rect.fromLTWH(u * .12, u * .14 + bob, u * .76, u * .5);
        _cloud(c, r, dark: true);
        for (var i = 0; i < 4; i++) {
          final ph = frac(t * .35 + i * .27);
          final x = r.left + r.width * (.26 + .48 * i / 3) + math.sin(t * 1.2 + i) * u * .03;
          final y = r.bottom - u * .02 + ph * u * .22;
          c.drawCircle(Offset(x, y), u * .03,
              _f(Colors.white.withValues(alpha: 1 - ph)));
        }
      case Kind.thunder:
        final r = Rect.fromLTWH(u * .1, u * .12 + bob, u * .8, u * .5);
        _cloud(c, r, dark: true, storm: true);
        final flick = 0.7 + 0.3 * math.sin(t * 9).abs();
        final bolt = Path()
          ..moveTo(u * .54, u * .55)
          ..lineTo(u * .42, u * .78)
          ..lineTo(u * .5, u * .78)
          ..lineTo(u * .44, u * .96)
          ..lineTo(u * .62, u * .7)
          ..lineTo(u * .53, u * .7)
          ..lineTo(u * .6, u * .55)
          ..close();
        c.drawPath(bolt, _f(const Color(0xFFFFD84D).withValues(alpha: flick)));
    }
  }

  void _cloud(Canvas c, Rect r, {required bool dark, bool storm = false}) {
    final w = r.width;
    final h = r.height;
    final path = Path()
      ..addOval(Rect.fromCircle(center: Offset(r.left + w * .28, r.top + h * .64), radius: h * .30))
      ..addOval(Rect.fromCircle(center: Offset(r.left + w * .50, r.top + h * .42), radius: h * .38))
      ..addOval(Rect.fromCircle(center: Offset(r.left + w * .74, r.top + h * .62), radius: h * .29))
      ..addRRect(RRect.fromRectAndRadius(
        Rect.fromLTRB(r.left + w * .12, r.top + h * .55, r.left + w * .88, r.top + h * .93),
        Radius.circular(h * .19),
      ));
    final top = storm
        ? const Color(0xFFAAB2DA)
        : dark
            ? const Color(0xFFD0D6EE)
            : const Color(0xFFFFFFFF);
    final bot = storm
        ? const Color(0xFF626B9E)
        : dark
            ? const Color(0xFF8F99C4)
            : const Color(0xFFC5CDFB);
    final paint = _f(top)
      ..shader = LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [top, bot],
      ).createShader(r);
    c.drawPath(path, paint);
  }

  void _sun(Canvas c, double u, Offset ctr, double r, double t) {
    c.drawCircle(
      ctr,
      r * 2.0,
      _f(const Color(0xFFFFD27A))
        ..shader = RadialGradient(
          colors: const [Color(0x66FFD27A), Color(0x00FFD27A)],
        ).createShader(Rect.fromCircle(center: ctr, radius: r * 2.0)),
    );
    for (var i = 0; i < 8; i++) {
      final a = t * .5 + i * math.pi / 4;
      final d = Offset(math.cos(a), math.sin(a));
      c.drawLine(ctr + d * (r * 1.45), ctr + d * (r * 1.85), _s(const Color(0xFFFFD27A), u * .045));
    }
    c.drawCircle(
      ctr,
      r,
      _f(const Color(0xFFFFD27A))
        ..shader = RadialGradient(
          center: const Alignment(-.3, -.3),
          colors: const [Color(0xFFFFF1B8), Color(0xFFFFB84D)],
        ).createShader(Rect.fromCircle(center: ctr, radius: r)),
    );
  }

  void _moon(Canvas c, double u, Offset ctr, double r) {
    c.drawCircle(
      ctr,
      r * 2,
      _f(const Color(0xFFC9D2FF))
        ..shader = RadialGradient(
          colors: const [Color(0x40C9D2FF), Color(0x00C9D2FF)],
        ).createShader(Rect.fromCircle(center: ctr, radius: r * 2)),
    );
    final moon = Path.combine(
      PathOperation.difference,
      Path()..addOval(Rect.fromCircle(center: ctr, radius: r)),
      Path()..addOval(Rect.fromCircle(center: ctr.translate(r * .5, -r * .32), radius: r * .88)),
    );
    c.drawPath(moon, _f(const Color(0xFFF3F4FF)));
  }

  void _drops(Canvas c, double u, Rect cr, double t, int n, Color col, double len) {
    for (var i = 0; i < n; i++) {
      final ph = frac(t * .9 + i * .31);
      final x = cr.left + cr.width * (.26 + .48 * (n == 1 ? .5 : i / (n - 1)));
      final y = cr.bottom - u * .02 + ph * u * .2;
      c.drawLine(Offset(x, y), Offset(x - u * .025, y + u * len),
          _s(col.withValues(alpha: 1 - ph), u * .04));
    }
  }

  @override
  bool shouldRepaint(covariant WeatherIconPainter old) =>
      old.code != code || old.isDay != isDay || old.engine != engine;
}
