import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../models/weather_models.dart';
import '../theme/app_text.dart';
import '../util/math_utils.dart';
import '../weather_engine/engine_controller.dart';

Paint _stroke(Color c, double w) => Paint()
  ..color = c
  ..style = PaintingStyle.stroke
  ..strokeWidth = w
  ..strokeCap = StrokeCap.round;

void _glowDot(Canvas c, Offset o, Color col) {
  c.drawCircle(
    o,
    9,
    Paint()
      ..color = col.withValues(alpha: 0.6)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 6),
  );
  c.drawCircle(o, 4.5, Paint()..color = Colors.white);
}

/// 240 degree arc gauge (feels-like).
class ArcGaugePainter extends CustomPainter {
  ArcGaugePainter({required this.fraction, required this.color, required this.progress, required this.engine})
      : super(repaint: engine);

  final double fraction;
  final Color color;
  final double progress;
  final EngineController engine;

  @override
  void paint(Canvas c, Size s) {
    final r = math.min(s.width, s.height) / 2 - 10;
    final ctr = Offset(s.width / 2, s.height / 2);
    final rect = Rect.fromCircle(center: ctr, radius: r);
    const start = 150 * math.pi / 180;
    const sweep = 240 * math.pi / 180;
    c.drawArc(rect, start, sweep, false, _stroke(Colors.white.withValues(alpha: 0.12), 8));
    final f = cl(fraction) * progress;
    c.drawArc(rect, start, sweep * f, false, _stroke(color, 8));
    final a = start + sweep * f;
    final pulse = 0.5 + 0.5 * math.sin(engine.rawTime * 2);
    _glowDot(c, ctr + Offset(math.cos(a), math.sin(a)) * r, color.withValues(alpha: 0.6 + 0.4 * pulse));
  }

  @override
  bool shouldRepaint(covariant ArcGaugePainter old) =>
      old.fraction != fraction || old.color != color || old.progress != progress;
}

/// Humidity: a circle filled with animated water.
class WaterPainter extends CustomPainter {
  WaterPainter({required this.level, required this.engine}) : super(repaint: engine);

  final double level; // 0..1
  final EngineController engine;

  @override
  void paint(Canvas c, Size s) {
    final d = math.min(s.width, s.height) - 6;
    final ctr = Offset(s.width / 2, s.height / 2);
    final rect = Rect.fromCenter(center: ctr, width: d, height: d);
    final circle = Path()..addOval(rect);
    c.drawCircle(ctr, d / 2, Paint()..color = Colors.white.withValues(alpha: 0.06));
    c.save();
    c.clipPath(circle);
    final top = rect.bottom - d * cl(level);
    final t = engine.rawTime;
    for (var layer = 0; layer < 2; layer++) {
      final path = Path()..moveTo(rect.left, rect.bottom);
      for (double x = 0; x <= d; x += 4) {
        final y = top + math.sin((x / d) * math.pi * 3 + t * (1.6 + layer * 0.7) + layer * 2) * 4;
        path.lineTo(rect.left + x, y);
      }
      path
        ..lineTo(rect.right, rect.bottom)
        ..close();
      c.drawPath(
        path,
        Paint()
          ..shader = LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              const Color(0xFF6EC6FF).withValues(alpha: layer == 0 ? 0.75 : 0.45),
              const Color(0xFF3B7BFF).withValues(alpha: layer == 0 ? 0.85 : 0.55),
            ],
          ).createShader(rect),
      );
    }
    c.restore();
    c.drawCircle(ctr, d / 2, _stroke(Colors.white.withValues(alpha: 0.22), 1.5));
  }

  @override
  bool shouldRepaint(covariant WaterPainter old) => old.level != level;
}

/// Wind compass with a rotating pointer.
class CompassPainter extends CustomPainter {
  CompassPainter({
    required this.dir,
    required this.speed01,
    required this.progress,
    required this.labels,
    required this.engine,
  }) : super(repaint: engine);

  final double dir;
  final double speed01;
  final double progress;
  final List<String> labels; // N E S W
  final EngineController engine;

  @override
  void paint(Canvas c, Size s) {
    final r = math.min(s.width, s.height) / 2 - 6;
    final ctr = Offset(s.width / 2, s.height / 2);
    c.drawCircle(ctr, r, _stroke(Colors.white.withValues(alpha: 0.16), 1.5));
    for (var i = 0; i < 72; i++) {
      final a = i * math.pi / 36;
      final major = i % 9 == 0;
      final l = major ? 9.0 : (i % 3 == 0 ? 5.0 : 3.0);
      final d = Offset(math.sin(a), -math.cos(a));
      c.drawLine(ctr + d * (r - 1), ctr + d * (r - 1 - l),
          _stroke(Colors.white.withValues(alpha: major ? 0.6 : 0.25), major ? 1.6 : 1));
    }
    final st = AppText.style(size: 10.5, weight: FontWeight.w800, color: AppText.dim(0.75));
    for (var i = 0; i < 4; i++) {
      final a = i * math.pi / 2;
      final p = ctr + Offset(math.sin(a), -math.cos(a)) * (r - 20);
      drawText(c, labels[i], p, st);
    }
    final heading = (dir + 180) * math.pi / 180 * progress;
    final wob = math.sin(engine.rawTime * 1.7) * 0.04 * (0.3 + speed01);
    final a = heading + wob;
    final d = Offset(math.sin(a), -math.cos(a));
    final tip = ctr + d * (r - 14);
    final perp = Offset(-d.dy, d.dx);
    final tri = Path()
      ..moveTo(tip.dx, tip.dy)
      ..lineTo(tip.dx - d.dx * 12 + perp.dx * 6, tip.dy - d.dy * 12 + perp.dy * 6)
      ..lineTo(tip.dx - d.dx * 12 - perp.dx * 6, tip.dy - d.dy * 12 - perp.dy * 6)
      ..close();
    c.drawPath(tri, Paint()..color = const Color(0xFF8CC8FF));
    c.drawCircle(ctr - d * (r - 14), 2.5, Paint()..color = Colors.white.withValues(alpha: 0.4));
  }

  @override
  bool shouldRepaint(covariant CompassPainter old) =>
      old.dir != dir || old.progress != progress || old.speed01 != speed01;
}

/// UV scale bar.
class UvBarPainter extends CustomPainter {
  UvBarPainter({required this.uv, required this.progress});

  final double uv;
  final double progress;

  @override
  void paint(Canvas c, Size s) {
    final cy = s.height / 2;
    final rect = RRect.fromRectAndRadius(Rect.fromLTWH(0, cy - 5, s.width, 10), const Radius.circular(5));
    c.drawRRect(
      rect,
      Paint()
        ..shader = const LinearGradient(colors: [
          Color(0xFF5EE0A0),
          Color(0xFFFFD166),
          Color(0xFFFFA24C),
          Color(0xFFFF6B6B),
          Color(0xFFB07CFF),
        ]).createShader(Rect.fromLTWH(0, 0, s.width, s.height)),
    );
    final x = cl(uv / 11) * s.width * progress;
    _glowDot(c, Offset(x, cy), Colors.white);
  }

  @override
  bool shouldRepaint(covariant UvBarPainter old) => old.uv != uv || old.progress != progress;
}

/// Half-circle pressure dial.
class PressurePainter extends CustomPainter {
  PressurePainter({required this.hpa, required this.progress, required this.engine}) : super(repaint: engine);

  final double hpa;
  final double progress;
  final EngineController engine;

  @override
  void paint(Canvas c, Size s) {
    final r = math.min(s.width / 2, s.height) - 8;
    final ctr = Offset(s.width / 2, s.height - 4);
    final rect = Rect.fromCircle(center: ctr, radius: r);
    c.drawArc(rect, math.pi, math.pi, false, _stroke(Colors.white.withValues(alpha: 0.12), 7));
    final f = cl((hpa - 960) / 100);
    c.drawArc(rect, math.pi, math.pi * f * progress, false, _stroke(const Color(0xFF8CC8FF), 7));
    for (var i = 0; i <= 10; i++) {
      final a = math.pi + math.pi * i / 10;
      final d = Offset(math.cos(a), math.sin(a));
      c.drawLine(ctr + d * (r - 12), ctr + d * (r - (i % 5 == 0 ? 22 : 17)),
          _stroke(Colors.white.withValues(alpha: 0.3), 1.2));
    }
    final a = math.pi + math.pi * f * progress + math.sin(engine.rawTime * 1.3) * 0.015;
    final d = Offset(math.cos(a), math.sin(a));
    c.drawLine(ctr, ctr + d * (r - 26), _stroke(Colors.white, 2.2));
    c.drawCircle(ctr, 4, Paint()..color = Colors.white);
  }

  @override
  bool shouldRepaint(covariant PressurePainter old) => old.hpa != hpa || old.progress != progress;
}

/// Mountain ridges fading with visibility.
class MountainPainter extends CustomPainter {
  MountainPainter({required this.km, required this.progress});

  final double km;
  final double progress;

  @override
  void paint(Canvas c, Size s) {
    const dists = [1.0, 4.0, 10.0, 22.0];
    for (var i = 0; i < 4; i++) {
      final d = dists[i];
      final a = cl((km - d * 0.4) / (d * 0.8)) * progress;
      final base = s.height;
      final h = s.height * (0.35 + 0.15 * (3 - i) / 3);
      final path = Path()..moveTo(0, base);
      final peaks = 3 + i;
      for (var k = 0; k <= peaks; k++) {
        final x = s.width * k / peaks;
        final off = hash01(i * 10 + k) * 0.4;
        final y = base - h * (0.5 + off + (k.isEven ? 0.15 : -0.1));
        path.lineTo(x, y);
      }
      path
        ..lineTo(s.width, base)
        ..close();
      c.drawPath(
        path,
        Paint()..color = Color.lerp(const Color(0xFFB9C4FF), const Color(0xFF2A3360), i / 3)!.withValues(alpha: 0.18 + 0.5 * a),
      );
    }
  }

  @override
  bool shouldRepaint(covariant MountainPainter old) => old.km != km || old.progress != progress;
}

/// Sunrise / sunset arc with a travelling sun.
class SunArcPainter extends CustomPainter {
  SunArcPainter({required this.p, required this.progress, required this.engine}) : super(repaint: engine);

  final double p; // 0..1 along the day
  final double progress;
  final EngineController engine;

  @override
  void paint(Canvas c, Size s) {
    final base = s.height - 8;
    final w = s.width;
    final arcH = s.height - 26;
    Offset at(double t) => Offset(
          8 + (w - 16) * t,
          base - math.sin(math.pi * t) * arcH,
        );
    final path = Path()..moveTo(at(0).dx, at(0).dy);
    for (var i = 1; i <= 60; i++) {
      final o = at(i / 60);
      path.lineTo(o.dx, o.dy);
    }
    c.drawPath(dashed(path, 5, 5), _stroke(Colors.white.withValues(alpha: 0.3), 1.5));
    c.drawLine(Offset(0, base), Offset(w, base), _stroke(Colors.white.withValues(alpha: 0.2), 1));

    final cur = cl(p) * progress;
    final done = Path()..moveTo(at(0).dx, at(0).dy);
    final n = math.max(2, (60 * cur).round());
    for (var i = 1; i <= n; i++) {
      final o = at(cur * i / n);
      done.lineTo(o.dx, o.dy);
    }
    c.drawPath(
      done,
      _stroke(const Color(0xFFFFC46B), 3),
    );
    final sun = at(cur);
    final pulse = 0.5 + 0.5 * math.sin(engine.rawTime * 2);
    c.drawCircle(
      sun,
      14 + 3 * pulse,
      Paint()
        ..color = const Color(0xFFFFC46B).withValues(alpha: 0.5)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 8),
    );
    c.drawCircle(sun, 6, Paint()..color = const Color(0xFFFFE9A8));
  }

  @override
  bool shouldRepaint(covariant SunArcPainter old) => old.p != p || old.progress != progress;
}

/// 24h precipitation: bars (mm) and a line (probability).
class PrecipPainter extends CustomPainter {
  PrecipPainter({required this.hours, required this.progress});

  final List<HourlyPoint> hours;
  final double progress;

  @override
  void paint(Canvas c, Size s) {
    if (hours.isEmpty) return;
    for (final f in [0.0, 0.5, 1.0]) {
      final y = s.height - 4 - (s.height - 8) * f;
      c.drawLine(Offset(0, y), Offset(s.width, y), _stroke(Colors.white.withValues(alpha: 0.08), 0.8));
    }
    var maxMm = 2.0;
    for (final h in hours) {
      maxMm = math.max(maxMm, h.precip);
    }
    final n = hours.length;
    final slot = s.width / n;
    for (var i = 0; i < n; i++) {
      final f = cl(hours[i].precip / maxMm) * progress;
      final bh = math.max(hours[i].precip > 0 ? 3.0 : 0.0, (s.height - 8) * f);
      final r = RRect.fromRectAndRadius(
        Rect.fromLTWH(i * slot + slot * 0.2, s.height - 4 - bh, slot * 0.6, bh),
        const Radius.circular(3),
      );
      c.drawRRect(r, Paint()..color = const Color(0xFF6FB6FF).withValues(alpha: 0.85));
    }
    final line = Path();
    for (var i = 0; i < n; i++) {
      final x = i * slot + slot / 2;
      final y = s.height - 4 - (s.height - 8) * cl(hours[i].precipProb / 100) * progress;
      if (i == 0) {
        line.moveTo(x, y);
      } else {
        line.lineTo(x, y);
      }
    }
    c.drawPath(line, _stroke(const Color(0xFFE6E9FF).withValues(alpha: 0.9), 1.8));
  }

  @override
  bool shouldRepaint(covariant PrecipPainter old) => old.hours != hours || old.progress != progress;
}

/// Segmented AQI gauge.
class AqiGaugePainter extends CustomPainter {
  AqiGaugePainter({required this.aqi, required this.progress, required this.engine}) : super(repaint: engine);

  final int aqi;
  final double progress;
  final EngineController engine;

  static const List<Color> _cols = [
    Color(0xFF5EE0A0),
    Color(0xFFFFD166),
    Color(0xFFFFA24C),
    Color(0xFFFF6B6B),
    Color(0xFFB07CFF),
    Color(0xFFE0457B),
  ];
  static const List<int> _edges = [0, 50, 100, 150, 200, 300, 500];

  @override
  void paint(Canvas c, Size s) {
    final r = math.min(s.width / 2, s.height) - 12;
    final ctr = Offset(s.width / 2, s.height - 6);
    final rect = Rect.fromCircle(center: ctr, radius: r);
    final seg = math.pi / 6;
    for (var i = 0; i < 6; i++) {
      c.drawArc(rect, math.pi + seg * i + 0.03, seg - 0.06, false, _stroke(_cols[i].withValues(alpha: 0.85), 10));
    }
    var idx = 5;
    for (var i = 0; i < 6; i++) {
      if (aqi <= _edges[i + 1]) {
        idx = i;
        break;
      }
    }
    final within = cl((aqi - _edges[idx]) / (_edges[idx + 1] - _edges[idx]));
    final f = (idx + within) / 6 * progress;
    final a = math.pi + math.pi * f;
    _glowDot(c, ctr + Offset(math.cos(a), math.sin(a)) * r, Colors.white);
  }

  @override
  bool shouldRepaint(covariant AqiGaugePainter old) => old.aqi != aqi || old.progress != progress;
}

class PollutantBarPainter extends CustomPainter {
  PollutantBarPainter({required this.frac, required this.progress});

  final double frac;
  final double progress;

  @override
  void paint(Canvas c, Size s) {
    final cy = s.height / 2;
    c.drawRRect(
      RRect.fromRectAndRadius(Rect.fromLTWH(0, cy - 3, s.width, 6), const Radius.circular(3)),
      Paint()..color = Colors.white.withValues(alpha: 0.1),
    );
    final f = cl(frac);
    final w = math.max(6.0, s.width * f * progress);
    final col = f < 0.5
        ? Color.lerp(const Color(0xFF5EE0A0), const Color(0xFFFFD166), f * 2)!
        : Color.lerp(const Color(0xFFFFD166), const Color(0xFFFF6B6B), (f - 0.5) * 2)!;
    c.drawRRect(
      RRect.fromRectAndRadius(Rect.fromLTWH(0, cy - 3, w, 6), const Radius.circular(3)),
      Paint()..color = col,
    );
  }

  @override
  bool shouldRepaint(covariant PollutantBarPainter old) => old.frac != frac || old.progress != progress;
}
