import 'package:flutter/material.dart';

import '../state/app_scope.dart';
import '../theme/app_text.dart';
import 'glass.dart';
import 'ui_icons.dart';

class InsightsCard extends StatelessWidget {
  const InsightsCard({super.key});

  @override
  Widget build(BuildContext context) {
    final app = AppScope.of(context);
    final i = app.insight;
    const accent = Color(0xFFB9C4FF);
    final tag = i == null
        ? ''
        : (app.insightLoading ? '${app.tr('ai_tag')}...' : app.tr(i.fromAi ? 'ai_tag' : 'smart_tag'));
    return Glass(
      radius: 28,
      blur: 24,
      padding: const EdgeInsets.all(18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const UiIcon(UiGlyph.sparkle, size: 20, color: accent),
              const SizedBox(width: 8),
              Expanded(
                child: Text(app.tr('ai_insights'),
                    style: AppText.style(size: 16, weight: FontWeight.w800)),
              ),
              if (i != null)
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: accent.withValues(alpha: 0.18),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(tag,
                      style: AppText.style(size: 11, weight: FontWeight.w800, color: accent)),
                ),
            ],
          ),
          const SizedBox(height: 12),
          if (i == null)
            const SizedBox(height: 60)
          else ...[
            Text(i.summary, style: AppText.style(size: 15, weight: FontWeight.w600, height: 1.5)),
            const SizedBox(height: 14),
            _Row(label: app.tr('wear'), text: i.wear),
            const SizedBox(height: 8),
            _Row(label: app.tr('best_time'), text: i.bestTime),
          ],
        ],
      ),
    );
  }
}

class _Row extends StatelessWidget {
  const _Row({required this.label, required this.text});

  final String label;
  final String text;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.06),
        borderRadius: BorderRadius.circular(18),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: AppText.style(size: 12, weight: FontWeight.w700, color: AppText.dim(0.6))),
          const SizedBox(height: 4),
          Text(text, style: AppText.style(size: 14, weight: FontWeight.w600, height: 1.4)),
        ],
      ),
    );
  }
}
