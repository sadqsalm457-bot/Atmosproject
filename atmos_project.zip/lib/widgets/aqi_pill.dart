import 'dart:ui' as ui;

import 'package:flutter/material.dart';

import '../models/weather_models.dart';
import '../state/app_scope.dart';
import '../theme/app_text.dart';
import 'ui_icons.dart';

Color aqiColor(int v) {
  if (v <= 50) return const Color(0xFF5EE0A0);
  if (v <= 100) return const Color(0xFFFFD166);
  if (v <= 150) return const Color(0xFFFFA24C);
  if (v <= 200) return const Color(0xFFFF6B6B);
  if (v <= 300) return const Color(0xFFB07CFF);
  return const Color(0xFFE0457B);
}

String aqiKey(int v) {
  if (v <= 50) return 'aqi_good';
  if (v <= 100) return 'aqi_moderate';
  if (v <= 150) return 'aqi_sensitive';
  if (v <= 200) return 'aqi_unhealthy';
  if (v <= 300) return 'aqi_very';
  return 'aqi_hazard';
}

class AqiPill extends StatelessWidget {
  const AqiPill({super.key, required this.air});

  final AirQuality air;

  @override
  Widget build(BuildContext context) {
    final app = AppScope.of(context);
    final col = aqiColor(air.aqi);
    return ClipRRect(
      borderRadius: BorderRadius.circular(22),
      child: BackdropFilter(
        filter: ui.ImageFilter.blur(sigmaX: 16, sigmaY: 16),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
          decoration: BoxDecoration(
            color: Colors.white.withValues(alpha: 0.12),
            borderRadius: BorderRadius.circular(22),
            border: Border.all(color: Colors.white.withValues(alpha: 0.14), width: 1),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              AqiGlyph(color: col, size: 18),
              const SizedBox(width: 8),
              Text(app.tr('aqi'), style: AppText.style(size: 13, weight: FontWeight.w700, color: AppText.dim(0.75))),
              const SizedBox(width: 6),
              Text('${air.aqi}', style: AppText.style(size: 14, weight: FontWeight.w800)),
              const SizedBox(width: 8),
              Container(width: 6, height: 6, decoration: BoxDecoration(color: col, shape: BoxShape.circle)),
              const SizedBox(width: 6),
              Text(app.tr(aqiKey(air.aqi)), style: AppText.style(size: 13, weight: FontWeight.w700)),
            ],
          ),
        ),
      ),
    );
  }
}
