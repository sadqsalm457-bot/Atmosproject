import 'package:flutter/material.dart';

class SkeletonView extends StatefulWidget {
  const SkeletonView({super.key});

  @override
  State<SkeletonView> createState() => _SkeletonViewState();
}

class _SkeletonViewState extends State<SkeletonView> with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 1400),
  )..repeat();

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  Widget _box(double w, double h, double r) => Container(
        width: w,
        height: h,
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(r)),
      );

  @override
  Widget build(BuildContext context) {
    final pad = MediaQuery.paddingOf(context);
    return AnimatedBuilder(
      animation: _c,
      builder: (context, _) {
        return ShaderMask(
          blendMode: BlendMode.srcIn,
          shaderCallback: (rect) => LinearGradient(
            begin: Alignment(-1.6 + 3.2 * _c.value, -0.3),
            end: Alignment(-0.6 + 3.2 * _c.value, 0.3),
            colors: [
              Colors.white.withValues(alpha: 0.10),
              Colors.white.withValues(alpha: 0.28),
              Colors.white.withValues(alpha: 0.10),
            ],
          ).createShader(rect),
          child: SingleChildScrollView(
            physics: const NeverScrollableScrollPhysics(),
            padding: EdgeInsets.fromLTRB(24, pad.top + 18, 24, pad.bottom + 24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [_box(130, 22, 11), Row(children: [_box(42, 42, 21), const SizedBox(width: 10), _box(42, 42, 21)])],
                ),
                const SizedBox(height: 40),
                _box(230, 150, 28),
                const SizedBox(height: 16),
                _box(210, 18, 9),
                const SizedBox(height: 16),
                _box(150, 36, 18),
                const SizedBox(height: 30),
                _box(double.infinity, 118, 28),
                const SizedBox(height: 18),
                _box(double.infinity, 330, 32),
              ],
            ),
          ),
        );
      },
    );
  }
}
