import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../state/app_scope.dart';
import '../theme/app_text.dart';
import '../util/math_utils.dart';
import '../weather_engine/engine_controller.dart';
import 'glass.dart';
import 'ui_icons.dart';
import 'weather_icons.dart';

class ForecastCard extends StatelessWidget {
  const ForecastCard({super.key, required this.onMore});

  final VoidCallback onMore;

  @override
  Widget build(BuildContext context) {
    final app = AppScope.of(context);
    final engine = AppScope.engineOf(context);
    final b = app.bundle;
    if (b == null) return const SizedBox.shrink();
    final rtl = app.rtl;
    final days = b.daily.take(5).toList();
    var wMin = double.infinity;
    var wMax = -double.infinity;
    for (final d in days) {
      wMin = math.min(wMin, d.min);
      wMax = math.max(wMax, d.max);
    }
    final today = b.today;

    return Glass(
      radius: 32,
      blur: 28,
      child: Stack(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 18, 20, 8),
            child: Column(
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Text(app.tr('forecast5'),
                          style: AppText.style(size: 17, weight: FontWeight.w800)),
                    ),
                    GestureDetector(
                      behavior: HitTestBehavior.opaque,
                      onTap: onMore,
                      child: Row(
                        children: [
                          Text(app.tr('more_details'),
                              style: AppText.style(size: 13, weight: FontWeight.w700, color: AppText.dim(0.7))),
                          const SizedBox(width: 2),
                          UiIcon(UiGlyph.chevron, size: 16, color: AppText.dim(0.7)),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 6),
                for (var i = 0; i < days.length; i++) ...[
                  Container(height: 0.5, color: Colors.white.withValues(alpha: 0.10)),
                  SizedBox(
                    height: 54,
                    child: Row(
                      children: [
                        SizedBox(
                          width: 70,
                          child: Text(
                            i == 0 || (days[i].date.day == today.date.day && days[i].date.month == today.date.month)
                                ? app.tr('today')
                                : app.tr('d${days[i].date.weekday}'),
                            style: AppText.style(size: 14.5, weight: FontWeight.w700),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                        WeatherIcon(code: days[i].code, isDay: true, size: 30),
                        const SizedBox(width: 8),
                        SizedBox(
                          width: 36,
                          child: Text(app.settings.tempText(days[i].min),
                              textAlign: TextAlign.end,
                              style: AppText.style(size: 14.5, weight: FontWeight.w600, color: AppText.dim(0.65))),
                        ),
                        Expanded(
                          child: Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 10),
                            child: SizedBox(
                              height: 20,
                              child: CustomPaint(
                                painter: RangeBarPainter(
                                  lo: days[i].min,
                                  hi: days[i].max,
                                  wMin: wMin,
                                  wMax: wMax,
                                  cur: i == 0 ? b.current.temp : null,
                                  rtl: rtl,
                                ),
                              ),
                            ),
                          ),
                        ),
                        SizedBox(
                          width: 36,
                          child: Text(app.settings.tempText(days[i].max),
                              style: AppText.style(size: 14.5, weight: FontWeight.w800)),
                        ),
                      ],
                    ),
                  ),
                ],
              ],
            ),
          ),
          Positioned.fill(
            child: IgnorePointer(
              child: CustomPaint(painter: GlassDropsPainter(engine)),
            ),
          ),
        ],
      ),
    );
  }
}

class RangeBarPainter extends CustomPainter {
  RangeBarPainter({
    required this.lo,
    required this.hi,
    required this.wMin,
    required this.wMax,
    required this.cur,
    required this.rtl,
  });

  final double lo;
  final double hi;
  final double wMin;
  final double wMax;
  final double? cur;
  final bool rtl;

  @override
  void paint(Canvas c, Size s) {
    final range = math.max(1.0, wMax - wMin);
    double xOf(double v) {
      final f = cl((v - wMin) / range);
      return (rtl ? 1 - f : f) * s.width;
    }

    final cy = s.height / 2;
    final track = RRect.fromRectAndRadius(
        Rect.fromLTWH(0, cy - 3, s.width, 6), const Radius.circular(3));
    c.drawRRect(track, Paint()..color = Colors.white.withValues(alpha: 0.12));

    var x1 = xOf(lo);
    var x2 = xOf(hi);
    if (x1 > x2) {
      final t = x1;
      x1 = x2;
      x2 = t;
    }
    if (x2 - x1 < 10) {
      final mid = (x1 + x2) / 2;
      x1 = mid - 5;
      x2 = mid + 5;
    }
    final seg = Rect.fromLTRB(x1, cy - 3, x2, cy + 3);
    final grad = LinearGradient(
      begin: rtl ? Alignment.centerRight : Alignment.centerLeft,
      end: rtl ? Alignment.centerLeft : Alignment.centerRight,
      colors: [tempColor(lo), tempColor((lo + hi) / 2), tempColor(hi)],
    );
    c.drawRRect(
      RRect.fromRectAndRadius(seg, const Radius.circular(3)),
      Paint()..shader = grad.createShader(seg),
    );

    final cv = cur;
    if (cv != null) {
      final mx = cl(xOf(cv), x1 + 3, x2 - 3);
      c.drawCircle(
        Offset(mx, cy),
        8,
        Paint()
          ..color = Colors.white.withValues(alpha: 0.55)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 5),
      );
      c.drawCircle(Offset(mx, cy), 4.2, Paint()..color = Colors.white);
    }
  }

  @override
  bool shouldRepaint(covariant RangeBarPainter old) =>
      old.lo != lo || old.hi != hi || old.wMin != wMin || old.wMax != wMax ||
      old.cur != cur || old.rtl != rtl;
}

class GlassDropsPainter extends CustomPainter {
  GlassDropsPainter(this.engine) : super(repaint: engine);

  final EngineController engine;

  // x fraction, y phase, speed, radius
  static const List<List<double>> _seeds = [
    [0.10, 0.10, 0.030, 2.6],
    [0.24, 0.55, 0.045, 2.0],
    [0.37, 0.30, 0.025, 3.0],
    [0.52, 0.80, 0.040, 2.2],
    [0.63, 0.15, 0.035, 2.8],
    [0.74, 0.65, 0.028, 2.4],
    [0.85, 0.40, 0.042, 2.0],
    [0.93, 0.90, 0.032, 2.6],
  ];

  @override
  void paint(Canvas canvas, Size size) {
    final rain = engine.current.rain;
    if (rain < 0.12) return;
    final a = cl(rain * 1.6) * 0.5;
    final t = engine.time;
    final trail = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.2
      ..strokeCap = StrokeCap.round;
    final head = Paint();
    for (var i = 0; i < _seeds.length; i++) {
      final sd = _seeds[i];
      final cycle = frac(sd[1] + t * sd[2]);
      final y = cycle * (size.height + 20) - 10;
      final x = sd[0] * size.width + math.sin(t * 0.8 + i) * 2;
      trail.color = Colors.white.withValues(alpha: a * 0.45);
      canvas.drawLine(Offset(x, y - 22), Offset(x, y), trail);
      head.color = Colors.white.withValues(alpha: a * 0.8);
      canvas.drawOval(Rect.fromCenter(center: Offset(x, y), width: sd[3] * 1.6, height: sd[3] * 2.2), head);
      head.color = Colors.white.withValues(alpha: a);
      canvas.drawCircle(Offset(x - 0.5, y - 0.6), 0.7, head);
    }
  }

  @override
  bool shouldRepaint(covariant GlassDropsPainter old) => old.engine != engine;
}
