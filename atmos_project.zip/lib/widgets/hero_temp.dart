import 'package:flutter/material.dart';

import '../theme/app_text.dart';

class HeroTemp extends StatelessWidget {
  const HeroTemp({super.key, required this.value});

  final int value;

  @override
  Widget build(BuildContext context) {
    return FittedBox(
      fit: BoxFit.scaleDown,
      alignment: AlignmentDirectional.centerStart,
      child: Row(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        textDirection: TextDirection.ltr,
        children: [
          Text(
            '$value',
            style: AppText.style(size: 180, weight: FontWeight.w800, spacing: -9, height: 0.95),
          ),
          const Padding(
            padding: EdgeInsets.only(top: 26, left: 4),
            child: CustomPaint(size: Size(34, 34), painter: _RingPainter()),
          ),
        ],
      ),
    );
  }
}

class _RingPainter extends CustomPainter {
  const _RingPainter();

  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()
      ..color = AppText.ink
      ..style = PaintingStyle.stroke
      ..strokeWidth = 4.5;
    canvas.drawCircle(size.center(Offset.zero), size.width / 2 - 3, p);
  }

  @override
  bool shouldRepaint(covariant _RingPainter old) => false;
}
