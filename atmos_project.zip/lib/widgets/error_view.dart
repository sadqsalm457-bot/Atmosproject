import 'package:flutter/material.dart';

import '../services/location_service.dart';
import '../state/app_scope.dart';
import '../state/app_state.dart';
import '../theme/app_text.dart';
import '../util/routes.dart';
import '../screens/search_screen.dart';
import 'glass.dart';
import 'weather_icons.dart';

class ErrorView extends StatelessWidget {
  const ErrorView({super.key, required this.kind, required this.onRetry});

  final LoadError kind;
  final Future<void> Function() onRetry;

  @override
  Widget build(BuildContext context) {
    final app = AppScope.of(context);
    String title;
    String message;
    String? actionLabel;
    VoidCallback? action;
    switch (kind) {
      case LoadError.denied:
      case LoadError.deniedForever:
        title = app.tr('err_denied_t');
        message = app.tr('err_denied_m');
        actionLabel = app.tr('open_settings');
        action = LocationService.openAppSettings;
      case LoadError.serviceOff:
        title = app.tr('err_service_t');
        message = app.tr('err_service_m');
        actionLabel = app.tr('open_settings');
        action = LocationService.openLocationSettings;
      case LoadError.network:
      case LoadError.none:
        title = app.tr('err_network_t');
        message = app.tr('err_network_m');
    }
    return SafeArea(
      child: Center(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 28),
          child: Glass(
            radius: 32,
            padding: const EdgeInsets.fromLTRB(24, 28, 24, 24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const WeatherIcon(code: 3, isDay: false, size: 84),
                const SizedBox(height: 14),
                Text(title,
                    textAlign: TextAlign.center,
                    style: AppText.style(size: 20, weight: FontWeight.w800)),
                const SizedBox(height: 8),
                Text(message,
                    textAlign: TextAlign.center,
                    style: AppText.style(size: 14, weight: FontWeight.w500, color: AppText.dim(0.75), height: 1.5)),
                const SizedBox(height: 22),
                Wrap(
                  alignment: WrapAlignment.center,
                  spacing: 10,
                  runSpacing: 10,
                  children: [
                    PillButton(label: app.tr('retry'), filled: true, onTap: () => onRetry()),
                    if (actionLabel != null && action != null)
                      PillButton(label: actionLabel, onTap: action),
                    PillButton(
                      label: app.tr('search_city'),
                      onTap: () => Navigator.of(context).push(fadeRoute<void>(const SearchScreen())),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
