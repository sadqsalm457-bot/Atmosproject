import 'package:flutter/material.dart';

import '../theme/app_text.dart';

enum UiGlyph { search, settings, chevron, back, close, pin, plus, trash, sparkle, check }

class UiIcon extends StatelessWidget {
  const UiIcon(
    this.glyph, {
    super.key,
    this.size = 22,
    this.color = AppText.ink,
    this.stroke = 1.8,
  });

  final UiGlyph glyph;
  final double size;
  final Color color;
  final double stroke;

  @override
  Widget build(BuildContext context) {
    final rtl = Directionality.of(context) == TextDirection.rtl;
    final flip = rtl && (glyph == UiGlyph.chevron || glyph == UiGlyph.back);
    Widget w = CustomPaint(size: Size.square(size), painter: _GlyphPainter(glyph, color, stroke));
    if (flip) w = Transform.flip(flipX: true, child: w);
    return w;
  }
}

class _GlyphPainter extends CustomPainter {
  _GlyphPainter(this.g, this.color, this.stroke);

  final UiGlyph g;
  final Color color;
  final double stroke;

  @override
  void paint(Canvas c, Size size) {
    final s = size.width;
    final p = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = stroke
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round;
    Offset o(double x, double y) => Offset(x * s, y * s);

    switch (g) {
      case UiGlyph.search:
        c.drawCircle(o(.43, .43), s * .26, p);
        c.drawLine(o(.63, .63), o(.86, .86), p);
      case UiGlyph.settings:
        final ys = [.26, .5, .74];
        final xs = [.66, .34, .62];
        for (var i = 0; i < 3; i++) {
          c.drawLine(o(.14, ys[i]), o(xs[i] - .1, ys[i]), p);
          c.drawLine(o(xs[i] + .1, ys[i]), o(.86, ys[i]), p);
          c.drawCircle(o(xs[i], ys[i]), s * .075, p);
        }
      case UiGlyph.chevron:
        c.drawPath(Path()..moveTo(s * .36, s * .2)..lineTo(s * .66, s * .5)..lineTo(s * .36, s * .8), p);
      case UiGlyph.back:
        c.drawPath(Path()..moveTo(s * .64, s * .2)..lineTo(s * .34, s * .5)..lineTo(s * .64, s * .8), p);
      case UiGlyph.close:
        c.drawLine(o(.24, .24), o(.76, .76), p);
        c.drawLine(o(.76, .24), o(.24, .76), p);
      case UiGlyph.pin:
        c.drawCircle(o(.5, .4), s * .2, p);
        c.drawPath(Path()..moveTo(s * .33, s * .52)..lineTo(s * .5, s * .88)..lineTo(s * .67, s * .52), p);
        c.drawCircle(o(.5, .4), s * .05, Paint()..color = color);
      case UiGlyph.plus:
        c.drawLine(o(.5, .2), o(.5, .8), p);
        c.drawLine(o(.2, .5), o(.8, .5), p);
      case UiGlyph.trash:
        c.drawLine(o(.2, .28), o(.8, .28), p);
        c.drawPath(Path()..moveTo(s * .4, s * .28)..lineTo(s * .4, s * .16)..lineTo(s * .6, s * .16)..lineTo(s * .6, s * .28), p);
        c.drawPath(Path()..moveTo(s * .28, s * .28)..lineTo(s * .32, s * .86)..lineTo(s * .68, s * .86)..lineTo(s * .72, s * .28), p);
        c.drawLine(o(.5, .42), o(.5, .72), p);
      case UiGlyph.sparkle:
        final path = Path()
          ..moveTo(s * .5, s * .08)
          ..quadraticBezierTo(s * .55, s * .45, s * .92, s * .5)
          ..quadraticBezierTo(s * .55, s * .55, s * .5, s * .92)
          ..quadraticBezierTo(s * .45, s * .55, s * .08, s * .5)
          ..quadraticBezierTo(s * .45, s * .45, s * .5, s * .08)
          ..close();
        c.drawPath(path, p);
      case UiGlyph.check:
        c.drawPath(Path()..moveTo(s * .22, s * .52)..lineTo(s * .43, s * .72)..lineTo(s * .78, s * .3), p);
    }
  }

  @override
  bool shouldRepaint(covariant _GlyphPainter old) =>
      old.g != g || old.color != color || old.stroke != stroke;
}

/// Painted air-quality glyph: three wind lines with curls.
class AqiGlyph extends StatelessWidget {
  const AqiGlyph({super.key, required this.color, this.size = 18});

  final Color color;
  final double size;

  @override
  Widget build(BuildContext context) =>
      CustomPaint(size: Size.square(size), painter: _AqiGlyphPainter(color));
}

class _AqiGlyphPainter extends CustomPainter {
  _AqiGlyphPainter(this.color);

  final Color color;

  @override
  void paint(Canvas c, Size size) {
    final s = size.width;
    final p = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = s * 0.1
      ..strokeCap = StrokeCap.round;
    final a = Path()
      ..moveTo(s * .1, s * .34)
      ..lineTo(s * .58, s * .34)
      ..cubicTo(s * .82, s * .34, s * .84, s * .1, s * .64, s * .12);
    final b = Path()
      ..moveTo(s * .1, s * .56)
      ..lineTo(s * .8, s * .56)
      ..cubicTo(s * .98, s * .56, s * .98, s * .82, s * .78, s * .8);
    final d = Path()
      ..moveTo(s * .1, s * .78)
      ..lineTo(s * .46, s * .78);
    c.drawPath(a, p);
    c.drawPath(b, p);
    c.drawPath(d, p);
  }

  @override
  bool shouldRepaint(covariant _AqiGlyphPainter old) => old.color != color;
}
