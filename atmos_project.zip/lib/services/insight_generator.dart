import 'package:intl/intl.dart';

import '../models/app_settings.dart';
import '../models/insight.dart';
import '../models/weather_models.dart';

class InsightGenerator {
  static String _fill(String t, Map<String, String> m) {
    var s = t;
    m.forEach((k, v) {
      s = s.replaceAll('{$k}', v);
    });
    return s;
  }

  static Insight local(
    WeatherBundle b,
    AppSettings s,
    String Function(String) tr,
  ) {
    final c = b.current;
    final today = b.today;
    final tf = DateFormat('HH:mm');
    final k = kindOf(c.code);
    final stormy = k == Kind.thunder;
    final snowy = k == Kind.snow;
    final rainyNow = k == Kind.drizzle ||
        k == Kind.rain ||
        k == Kind.showers ||
        k == Kind.freezing ||
        stormy;

    HourlyPoint? wet;
    for (final h in b.nextHours(12)) {
      if (h.precipProb >= 50 && (wet == null || h.precipProb > wet.precipProb)) {
        wet = h;
      }
    }

    final cond = tr(conditionKey(c.code, c.isDay));
    final s1 = _fill(tr('ins_now'), {
      'cond': cond,
      't': s.tempText(c.temp),
      'f': s.tempText(c.feelsLike),
      'lo': s.tempText(today.min),
      'hi': s.tempText(today.max),
    });

    String s2;
    if (stormy) {
      s2 = tr('ins_storm');
    } else if (snowy) {
      s2 = tr('ins_snow');
    } else if (rainyNow) {
      s2 = tr('ins_rain_now');
    } else if (wet != null) {
      s2 = _fill(tr('ins_rain'), {'time': tf.format(wet.time)});
    } else if (c.windKmh >= 35) {
      s2 = _fill(tr('ins_wind'), {'w': s.windText(c.windKmh)});
    } else if (c.uv >= 6 && c.isDay) {
      s2 = tr('ins_uv');
    } else {
      s2 = tr('ins_calm');
    }

    final f = c.feelsLike;
    var wear = f <= 0
        ? tr('wear_freeze')
        : f <= 10
            ? tr('wear_cold')
            : f <= 17
                ? tr('wear_cool')
                : f <= 24
                    ? tr('wear_mild')
                    : f <= 31
                        ? tr('wear_warm')
                        : tr('wear_hot');
    if (rainyNow || wet != null) wear = '$wear ${tr('wear_umbrella')}';
    if (c.uv >= 6 && c.isDay) wear = '$wear ${tr('wear_sun')}';

    HourlyPoint? best;
    var bestScore = 1e9;
    for (final h in b.nextHours(24)) {
      final hr = h.time.hour;
      if (hr < 6 || hr > 21) continue;
      final score = h.precipProb * 0.6 +
          (h.feels - 21).abs() * 2.5 +
          h.windKmh * 0.35 +
          (h.uv > 7 ? (h.uv - 7) * 4 : 0);
      if (score < bestScore) {
        bestScore = score;
        best = h;
      }
    }
    best ??= b.nextHours(2).last;
    final start = best.time;
    final end = start.add(const Duration(hours: 2));
    final now = b.localNow;
    final tomorrow = start.day != now.day;
    final label = '${tomorrow ? tr('tomorrow_prefix') : ''}${tf.format(start)} - ${tf.format(end)}';

    return Insight(summary: '$s1 $s2', wear: wear, bestTime: label, fromAi: false);
  }
}
