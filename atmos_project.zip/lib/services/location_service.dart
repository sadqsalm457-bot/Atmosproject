import 'package:geolocator/geolocator.dart';

enum LocationFailure { serviceOff, denied, deniedForever, unknown }

class LocationResult {
  const LocationResult.ok(this.lat, this.lon) : failure = null;
  const LocationResult.fail(this.failure)
      : lat = 0,
        lon = 0;

  final double lat;
  final double lon;
  final LocationFailure? failure;
}

class LocationService {
  static Future<LocationResult> locate() async {
    try {
      final enabled = await Geolocator.isLocationServiceEnabled();
      if (!enabled) return const LocationResult.fail(LocationFailure.serviceOff);

      var permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
      }
      if (permission == LocationPermission.denied) {
        return const LocationResult.fail(LocationFailure.denied);
      }
      if (permission == LocationPermission.deniedForever) {
        return const LocationResult.fail(LocationFailure.deniedForever);
      }

      try {
        final pos = await Geolocator.getCurrentPosition(
          locationSettings: LocationSettings(
            accuracy: LocationAccuracy.low,
            timeLimit: const Duration(seconds: 12),
          ),
        );
        return LocationResult.ok(pos.latitude, pos.longitude);
      } catch (_) {
        final last = await Geolocator.getLastKnownPosition();
        if (last != null) return LocationResult.ok(last.latitude, last.longitude);
        return const LocationResult.fail(LocationFailure.unknown);
      }
    } catch (_) {
      return const LocationResult.fail(LocationFailure.unknown);
    }
  }

  static Future<bool> openAppSettings() => Geolocator.openAppSettings();

  static Future<bool> openLocationSettings() => Geolocator.openLocationSettings();
}
