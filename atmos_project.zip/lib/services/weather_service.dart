import 'dart:async';
import 'dart:convert';

import 'package:http/http.dart' as http;

import '../models/weather_models.dart';

class WeatherException implements Exception {
  WeatherException(this.message);
  final String message;
  @override
  String toString() => 'WeatherException: $message';
}

class WeatherService {
  static Future<Map<String, dynamic>> _getJson(Uri uri) async {
    final r = await http.get(uri).timeout(const Duration(seconds: 15));
    if (r.statusCode != 200) {
      throw WeatherException('HTTP ${r.statusCode}');
    }
    return jsonDecode(utf8.decode(r.bodyBytes)) as Map<String, dynamic>;
  }

  static Future<WeatherBundle> fetch(CityPlace place) async {
    final lat = place.lat.toStringAsFixed(4);
    final lon = place.lon.toStringAsFixed(4);

    final forecastUri = Uri.https('api.open-meteo.com', '/v1/forecast', {
      'latitude': lat,
      'longitude': lon,
      'current':
          'temperature_2m,relative_humidity_2m,apparent_temperature,is_day,precipitation,weather_code,cloud_cover,pressure_msl,wind_speed_10m,wind_direction_10m',
      'hourly':
          'temperature_2m,apparent_temperature,precipitation_probability,precipitation,weather_code,is_day,visibility,uv_index,wind_speed_10m',
      'daily':
          'weather_code,temperature_2m_max,temperature_2m_min,sunrise,sunset,uv_index_max,precipitation_sum',
      'timezone': 'auto',
      'forecast_days': '5',
      'wind_speed_unit': 'kmh',
      'temperature_unit': 'celsius',
    });

    final airUri = Uri.https('air-quality-api.open-meteo.com', '/v1/air-quality', {
      'latitude': lat,
      'longitude': lon,
      'current':
          'us_aqi,pm10,pm2_5,nitrogen_dioxide,ozone,sulphur_dioxide,carbon_monoxide',
      'timezone': 'auto',
    });

    final airFuture = _getJson(airUri).then<Map<String, dynamic>?>(
      (v) => v,
      onError: (Object _) => null,
    );
    final forecast = await _getJson(forecastUri);
    final air = await airFuture;

    return WeatherBundle.parse(place, forecast, air, DateTime.now());
  }

  static Future<List<CityPlace>> search(String query, String lang) async {
    final uri = Uri.https('geocoding-api.open-meteo.com', '/v1/search', {
      'name': query,
      'count': '8',
      'language': lang,
      'format': 'json',
    });
    final j = await _getJson(uri);
    final res = j['results'];
    if (res is! List) return const [];
    final out = <CityPlace>[];
    for (final e in res) {
      if (e is! Map<String, dynamic>) continue;
      final la = e['latitude'];
      final lo = e['longitude'];
      if (la is! num || lo is! num) continue;
      out.add(CityPlace(
        name: (e['name'] ?? '').toString(),
        country: (e['country'] ?? '').toString(),
        admin: (e['admin1'] ?? '').toString(),
        lat: la.toDouble(),
        lon: lo.toDouble(),
      ));
    }
    return out;
  }
}
