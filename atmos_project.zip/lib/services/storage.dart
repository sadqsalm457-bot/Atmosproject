import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import '../models/app_settings.dart';
import '../models/weather_models.dart';

class Storage {
  Storage(this._p);

  final SharedPreferences _p;

  static Future<Storage> open() async => Storage(await SharedPreferences.getInstance());

  static const String _kSettings = 'settings';
  static const String _kCities = 'cities';
  static const String _kSelected = 'selected';
  static const String _kBundle = 'bundle';

  AppSettings loadSettings() {
    final s = _p.getString(_kSettings);
    if (s == null) return const AppSettings();
    try {
      return AppSettings.fromJson(jsonDecode(s) as Map<String, dynamic>);
    } catch (_) {
      return const AppSettings();
    }
  }

  Future<void> saveSettings(AppSettings s) =>
      _p.setString(_kSettings, jsonEncode(s.toJson()));

  List<CityPlace> loadCities() {
    final s = _p.getString(_kCities);
    if (s == null) return [];
    try {
      final l = jsonDecode(s) as List;
      return l.map((e) => CityPlace.fromJson(e as Map<String, dynamic>)).toList();
    } catch (_) {
      return [];
    }
  }

  Future<void> saveCities(List<CityPlace> cities) =>
      _p.setString(_kCities, jsonEncode(cities.map((c) => c.toJson()).toList()));

  CityPlace? loadSelected() {
    final s = _p.getString(_kSelected);
    if (s == null) return null;
    try {
      return CityPlace.fromJson(jsonDecode(s) as Map<String, dynamic>);
    } catch (_) {
      return null;
    }
  }

  Future<void> saveSelected(CityPlace? p) => p == null
      ? _p.remove(_kSelected)
      : _p.setString(_kSelected, jsonEncode(p.toJson()));

  WeatherBundle? loadBundle() {
    final s = _p.getString(_kBundle);
    if (s == null) return null;
    try {
      final m = jsonDecode(s) as Map<String, dynamic>;
      return WeatherBundle.parse(
        CityPlace.fromJson(m['place'] as Map<String, dynamic>),
        m['f'] as Map<String, dynamic>,
        m['a'] as Map<String, dynamic>?,
        DateTime.parse(m['t'] as String),
      );
    } catch (_) {
      return null;
    }
  }

  Future<void> saveBundle(WeatherBundle b) => _p.setString(
        _kBundle,
        jsonEncode({
          'place': b.place.toJson(),
          'f': b.forecastRaw,
          'a': b.airRaw,
          't': b.fetchedAt.toIso8601String(),
        }),
      );
}
