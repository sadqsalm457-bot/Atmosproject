class Insight {
  const Insight({
    required this.summary,
    required this.wear,
    required this.bestTime,
    required this.fromAi,
  });

  final String summary;
  final String wear;
  final String bestTime;
  final bool fromAi;
}
