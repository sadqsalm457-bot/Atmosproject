double _n(dynamic v) => v is num ? v.toDouble() : 0.0;

class CityPlace {
  const CityPlace({
    required this.name,
    required this.country,
    required this.lat,
    required this.lon,
    this.admin = '',
    this.gps = false,
  });

  final String name;
  final String country;
  final String admin;
  final double lat;
  final double lon;
  final bool gps;

  CityPlace copyWith({String? name}) => CityPlace(
        name: name ?? this.name,
        country: country,
        admin: admin,
        lat: lat,
        lon: lon,
        gps: gps,
      );

  bool sameAs(CityPlace o) =>
      (lat - o.lat).abs() < 0.01 && (lon - o.lon).abs() < 0.01;

  String get subtitle {
    final parts = <String>[
      if (admin.isNotEmpty) admin,
      if (country.isNotEmpty) country,
    ];
    return parts.join(', ');
  }

  Map<String, dynamic> toJson() => {
        'name': name,
        'country': country,
        'admin': admin,
        'lat': lat,
        'lon': lon,
        'gps': gps,
      };

  factory CityPlace.fromJson(Map<String, dynamic> j) => CityPlace(
        name: (j['name'] ?? '').toString(),
        country: (j['country'] ?? '').toString(),
        admin: (j['admin'] ?? '').toString(),
        lat: _n(j['lat']),
        lon: _n(j['lon']),
        gps: j['gps'] == true,
      );
}

enum Kind {
  clear,
  mainlyClear,
  partly,
  overcast,
  fog,
  drizzle,
  rain,
  freezing,
  snow,
  showers,
  thunder,
}

Kind kindOf(int c) {
  if (c == 0) return Kind.clear;
  if (c == 1) return Kind.mainlyClear;
  if (c == 2) return Kind.partly;
  if (c == 3) return Kind.overcast;
  if (c == 45 || c == 48) return Kind.fog;
  if (c >= 51 && c <= 55) return Kind.drizzle;
  if (c == 56 || c == 57 || c == 66 || c == 67) return Kind.freezing;
  if (c >= 61 && c <= 65) return Kind.rain;
  if ((c >= 71 && c <= 77) || c == 85 || c == 86) return Kind.snow;
  if (c >= 80 && c <= 82) return Kind.showers;
  if (c >= 95) return Kind.thunder;
  return Kind.overcast;
}

String conditionKey(int code, bool isDay) {
  switch (code) {
    case 0:
      return isDay ? 'c_clear' : 'c_clear_night';
    case 1:
      return 'c_mainly_clear';
    case 2:
      return 'c_partly';
    case 3:
      return 'c_overcast';
    case 45:
    case 48:
      return 'c_fog';
    case 51:
    case 53:
    case 55:
      return 'c_drizzle';
    case 56:
    case 57:
      return 'c_freezing_drizzle';
    case 61:
      return 'c_rain_light';
    case 63:
      return 'c_rain';
    case 65:
      return 'c_rain_heavy';
    case 66:
    case 67:
      return 'c_freezing_rain';
    case 71:
      return 'c_snow_light';
    case 73:
      return 'c_snow';
    case 75:
      return 'c_snow_heavy';
    case 77:
      return 'c_snow_grains';
    case 80:
      return 'c_showers_light';
    case 81:
      return 'c_showers';
    case 82:
      return 'c_showers_heavy';
    case 85:
    case 86:
      return 'c_snow_showers';
    case 95:
      return 'c_thunder';
    case 96:
    case 99:
      return 'c_thunder_hail';
    default:
      return 'c_overcast';
  }
}

class CurrentWeather {
  const CurrentWeather({
    required this.time,
    required this.temp,
    required this.feelsLike,
    required this.humidity,
    required this.precip,
    required this.cloud,
    required this.windKmh,
    required this.windDir,
    required this.code,
    required this.isDay,
    required this.pressure,
    required this.visibility,
    required this.uv,
  });

  final DateTime time;
  final double temp;
  final double feelsLike;
  final int humidity;
  final double precip;
  final int cloud;
  final double windKmh;
  final double windDir;
  final int code;
  final bool isDay;
  final double pressure;
  final double visibility;
  final double uv;
}

class HourlyPoint {
  const HourlyPoint({
    required this.time,
    required this.temp,
    required this.feels,
    required this.code,
    required this.precipProb,
    required this.precip,
    required this.isDay,
    required this.windKmh,
    required this.visibility,
    required this.uv,
  });

  final DateTime time;
  final double temp;
  final double feels;
  final int code;
  final double precipProb;
  final double precip;
  final bool isDay;
  final double windKmh;
  final double visibility;
  final double uv;
}

class DailyPoint {
  const DailyPoint({
    required this.date,
    required this.min,
    required this.max,
    required this.code,
    required this.precipSum,
    required this.sunrise,
    required this.sunset,
    required this.uvMax,
  });

  final DateTime date;
  final double min;
  final double max;
  final int code;
  final double precipSum;
  final DateTime sunrise;
  final DateTime sunset;
  final double uvMax;
}

class AirQuality {
  const AirQuality({
    required this.aqi,
    required this.pm25,
    required this.pm10,
    required this.no2,
    required this.o3,
    required this.so2,
    required this.co,
  });

  final int aqi;
  final double pm25;
  final double pm10;
  final double no2;
  final double o3;
  final double so2;
  final double co;
}

class WeatherBundle {
  WeatherBundle({
    required this.place,
    required this.current,
    required this.hourly,
    required this.daily,
    required this.air,
    required this.fetchedAt,
    required this.forecastRaw,
    required this.airRaw,
  });

  final CityPlace place;
  final CurrentWeather current;
  final List<HourlyPoint> hourly;
  final List<DailyPoint> daily;
  final AirQuality? air;
  final DateTime fetchedAt;
  final Map<String, dynamic> forecastRaw;
  final Map<String, dynamic>? airRaw;

  /// Wall-clock time at the forecast location, advanced since the fetch.
  DateTime get localNow {
    final d = DateTime.now().difference(fetchedAt);
    return current.time.add(d.isNegative ? Duration.zero : d);
  }

  int get hourIndex {
    final n = localNow;
    var idx = 0;
    for (var i = 0; i < hourly.length; i++) {
      if (!hourly[i].time.isAfter(n)) {
        idx = i;
      } else {
        break;
      }
    }
    return idx;
  }

  List<HourlyPoint> nextHours(int count) {
    final s = hourIndex;
    final e = (s + count) > hourly.length ? hourly.length : s + count;
    return hourly.sublist(s, e);
  }

  DailyPoint get today {
    final n = localNow;
    for (final d in daily) {
      if (d.date.year == n.year && d.date.month == n.month && d.date.day == n.day) {
        return d;
      }
    }
    return daily.first;
  }

  static WeatherBundle parse(
    CityPlace place,
    Map<String, dynamic> f,
    Map<String, dynamic>? a,
    DateTime fetchedAt,
  ) {
    final cur = f['current'] as Map<String, dynamic>;
    final h = f['hourly'] as Map<String, dynamic>;
    final d = f['daily'] as Map<String, dynamic>;

    final ht = (h['time'] as List).map((e) => e.toString()).toList();
    double hv(String k, int i) {
      final l = h[k];
      return (l is List && i < l.length) ? _n(l[i]) : 0.0;
    }

    final hourly = <HourlyPoint>[
      for (var i = 0; i < ht.length; i++)
        HourlyPoint(
          time: DateTime.parse(ht[i]),
          temp: hv('temperature_2m', i),
          feels: hv('apparent_temperature', i),
          code: hv('weather_code', i).round(),
          precipProb: hv('precipitation_probability', i),
          precip: hv('precipitation', i),
          isDay: hv('is_day', i) > 0.5,
          windKmh: hv('wind_speed_10m', i),
          visibility: hv('visibility', i),
          uv: hv('uv_index', i),
        ),
    ];

    final now = DateTime.parse(cur['time'].toString());
    var idx = 0;
    for (var i = 0; i < hourly.length; i++) {
      if (!hourly[i].time.isAfter(now)) {
        idx = i;
      } else {
        break;
      }
    }
    final hp = hourly[idx];

    final current = CurrentWeather(
      time: now,
      temp: _n(cur['temperature_2m']),
      feelsLike: _n(cur['apparent_temperature']),
      humidity: _n(cur['relative_humidity_2m']).round(),
      precip: _n(cur['precipitation']),
      cloud: _n(cur['cloud_cover']).round(),
      windKmh: _n(cur['wind_speed_10m']),
      windDir: _n(cur['wind_direction_10m']),
      code: _n(cur['weather_code']).round(),
      isDay: _n(cur['is_day']) > 0.5,
      pressure: _n(cur['pressure_msl']),
      visibility: hp.visibility,
      uv: hp.uv,
    );

    final dt = (d['time'] as List).map((e) => e.toString()).toList();
    double dv(String k, int i) {
      final l = d[k];
      return (l is List && i < l.length) ? _n(l[i]) : 0.0;
    }

    String ds(String k, int i) => ((d[k] as List)[i]).toString();

    final daily = <DailyPoint>[
      for (var i = 0; i < dt.length; i++)
        DailyPoint(
          date: DateTime.parse(dt[i]),
          min: dv('temperature_2m_min', i),
          max: dv('temperature_2m_max', i),
          code: dv('weather_code', i).round(),
          precipSum: dv('precipitation_sum', i),
          sunrise: DateTime.parse(ds('sunrise', i)),
          sunset: DateTime.parse(ds('sunset', i)),
          uvMax: dv('uv_index_max', i),
        ),
    ];

    AirQuality? air;
    final ac = a?['current'];
    if (ac is Map<String, dynamic> && ac['us_aqi'] != null) {
      air = AirQuality(
        aqi: _n(ac['us_aqi']).round(),
        pm25: _n(ac['pm2_5']),
        pm10: _n(ac['pm10']),
        no2: _n(ac['nitrogen_dioxide']),
        o3: _n(ac['ozone']),
        so2: _n(ac['sulphur_dioxide']),
        co: _n(ac['carbon_monoxide']),
      );
    }

    var p = place;
    if (place.gps && place.name.isEmpty) {
      final tz = (f['timezone'] ?? '').toString();
      final city = tz.contains('/') ? tz.split('/').last.replaceAll('_', ' ') : tz;
      p = place.copyWith(name: city);
    }

    return WeatherBundle(
      place: p,
      current: current,
      hourly: hourly,
      daily: daily,
      air: air,
      fetchedAt: fetchedAt,
      forecastRaw: f,
      airRaw: a,
    );
  }
}
