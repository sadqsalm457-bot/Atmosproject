enum WindUnit { kmh, ms, mph }

class AppSettings {
  const AppSettings({
    this.fahrenheit = false,
    this.windUnit = WindUnit.kmh,
    this.lang = 'en',
    this.apiKey = '',
  });

  final bool fahrenheit;
  final WindUnit windUnit;
  final String lang;
  final String apiKey;

  AppSettings copyWith({
    bool? fahrenheit,
    WindUnit? windUnit,
    String? lang,
    String? apiKey,
  }) {
    return AppSettings(
      fahrenheit: fahrenheit ?? this.fahrenheit,
      windUnit: windUnit ?? this.windUnit,
      lang: lang ?? this.lang,
      apiKey: apiKey ?? this.apiKey,
    );
  }

  double temp(double c) => fahrenheit ? c * 9 / 5 + 32 : c;

  String tempText(double c) => '${temp(c).round()}\u00B0';

  double wind(double kmh) {
    switch (windUnit) {
      case WindUnit.kmh:
        return kmh;
      case WindUnit.ms:
        return kmh / 3.6;
      case WindUnit.mph:
        return kmh * 0.621371;
    }
  }

  String get windLabel {
    switch (windUnit) {
      case WindUnit.kmh:
        return 'km/h';
      case WindUnit.ms:
        return 'm/s';
      case WindUnit.mph:
        return 'mph';
    }
  }

  String windText(double kmh) => '${wind(kmh).round()} $windLabel';

  String get tempLabel => fahrenheit ? 'F' : 'C';

  Map<String, dynamic> toJson() => {
        'f': fahrenheit,
        'w': windUnit.index,
        'l': lang,
        'k': apiKey,
      };

  factory AppSettings.fromJson(Map<String, dynamic> j) {
    var wi = (j['w'] is int) ? j['w'] as int : 0;
    if (wi < 0 || wi >= WindUnit.values.length) wi = 0;
    return AppSettings(
      fahrenheit: j['f'] == true,
      windUnit: WindUnit.values[wi],
      lang: (j['l'] ?? 'en').toString(),
      apiKey: (j['k'] ?? '').toString(),
    );
  }
}
